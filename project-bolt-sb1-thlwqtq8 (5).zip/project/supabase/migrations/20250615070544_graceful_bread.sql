/*
  # 認証システムのデータベース設計

  1. 新しいテーブル
    - `profiles`
      - `id` (uuid, primary key, references auth.users)
      - `email` (text)
      - `full_name` (text)
      - `avatar_url` (text, optional)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `user_progress`
      - `user_id` (uuid, references auth.users.id) - 型をuuidに修正
      - その他の進捗データ

  2. セキュリティ
    - すべてのテーブルでRLSを有効化
    - ユーザーは自分のデータのみアクセス可能
    - 認証されたユーザーのみアクセス許可
*/

-- プロファイルテーブルの作成
CREATE TABLE IF NOT EXISTS profiles (
  id uuid REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  email text UNIQUE NOT NULL,
  full_name text,
  avatar_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- ユーザー進捗テーブルの作成（user_idをuuid型に修正）
CREATE TABLE IF NOT EXISTS user_progress (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  current_lesson integer DEFAULT 1,
  total_lessons_completed integer DEFAULT 0,
  total_points integer DEFAULT 0,
  streak integer DEFAULT 0,
  last_study_date text DEFAULT now()::text,
  lesson_progress jsonb DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- RLSを有効化
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_progress ENABLE ROW LEVEL SECURITY;

-- プロファイルのポリシー
DO $$
BEGIN
  -- 既存のポリシーを削除（存在する場合）
  DROP POLICY IF EXISTS "Users can view own profile" ON profiles;
  DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
  DROP POLICY IF EXISTS "Users can insert own profile" ON profiles;
  
  -- 新しいポリシーを作成
  CREATE POLICY "Users can view own profile"
    ON profiles
    FOR SELECT
    TO authenticated
    USING (auth.uid() = id);

  CREATE POLICY "Users can update own profile"
    ON profiles
    FOR UPDATE
    TO authenticated
    USING (auth.uid() = id);

  CREATE POLICY "Users can insert own profile"
    ON profiles
    FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = id);
END $$;

-- user_progressのポリシー（user_idがuuid型なので::textキャストを削除）
DO $$
BEGIN
  -- 既存のポリシーを削除（存在する場合）
  DROP POLICY IF EXISTS "Users can view own progress" ON user_progress;
  DROP POLICY IF EXISTS "Users can update own progress" ON user_progress;
  DROP POLICY IF EXISTS "Users can insert own progress" ON user_progress;
  
  -- 新しいポリシーを作成
  CREATE POLICY "Users can view own progress"
    ON user_progress
    FOR SELECT
    TO authenticated
    USING (auth.uid() = user_id);

  CREATE POLICY "Users can update own progress"
    ON user_progress
    FOR UPDATE
    TO authenticated
    USING (auth.uid() = user_id);

  CREATE POLICY "Users can insert own progress"
    ON user_progress
    FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = user_id);
END $$;

-- プロファイル作成のトリガー関数（user_idをuuid型で挿入）
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (
    new.id,
    new.email,
    COALESCE(new.raw_user_meta_data->>'full_name', new.email)
  );
  
  INSERT INTO public.user_progress (
    user_id,
    current_lesson,
    total_lessons_completed,
    total_points,
    streak,
    last_study_date,
    lesson_progress
  )
  VALUES (
    new.id,  -- uuid型として直接挿入（::textキャストを削除）
    1,
    0,
    0,
    0,
    now()::text,
    '[]'::jsonb
  );
  
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 新規ユーザー登録時のトリガー
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();

-- プロファイル更新時のupdated_at自動更新
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS trigger AS $$
BEGIN
  new.updated_at = now();
  RETURN new;
END;
$$ LANGUAGE plpgsql;

-- プロファイルのupdated_atトリガー
DROP TRIGGER IF EXISTS handle_profiles_updated_at ON profiles;
CREATE TRIGGER handle_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE PROCEDURE public.handle_updated_at();

-- user_progressのupdated_atトリガー
DROP TRIGGER IF EXISTS handle_user_progress_updated_at ON user_progress;
CREATE TRIGGER handle_user_progress_updated_at
  BEFORE UPDATE ON user_progress
  FOR EACH ROW EXECUTE PROCEDURE public.handle_updated_at();
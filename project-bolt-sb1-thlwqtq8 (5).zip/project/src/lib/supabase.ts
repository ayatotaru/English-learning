import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

// 環境変数の検証
if (!supabaseUrl || !supabaseAnonKey) {
  console.error('Supabase環境変数が設定されていません');
  console.error('VITE_SUPABASE_URL:', supabaseUrl ? '設定済み' : '未設定');
  console.error('VITE_SUPABASE_ANON_KEY:', supabaseAnonKey ? '設定済み' : '未設定');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
    flowType: 'pkce'
  },
  global: {
    headers: {
      'X-Client-Info': 'english-learning-app'
    }
  },
  db: {
    schema: 'public'
  },
  realtime: {
    params: {
      eventsPerSecond: 10
    }
  }
});

// 接続テスト（非同期で実行、エラーでもアプリを停止させない）
const testConnection = async () => {
  try {
    console.log('Supabase接続テスト開始...');
    
    // より軽量な接続テスト
    const startTime = Date.now();
    const { data, error } = await Promise.race([
      supabase.auth.getSession(),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Connection timeout')), 5000)
      )
    ]) as any;
    
    const duration = Date.now() - startTime;
    
    if (error) {
      console.warn('Supabase接続警告:', error.message);
    } else {
      console.log(`Supabase接続成功 (${duration}ms):`, !!data.session ? 'セッション有り' : 'セッション無し');
    }
  } catch (err: any) {
    console.warn('Supabase接続テストエラー:', err.message);
  }
};

// 非同期で接続テストを実行（アプリの起動をブロックしない）
if (supabaseUrl && supabaseAnonKey) {
  testConnection();
} else {
  console.warn('Supabase環境変数が未設定のため、接続テストをスキップします');
}

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          email: string;
          full_name: string | null;
          avatar_url: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          email: string;
          full_name?: string | null;
          avatar_url?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          email?: string;
          full_name?: string | null;
          avatar_url?: string | null;
          updated_at?: string;
        };
      };
      user_progress: {
        Row: {
          id: string;
          user_id: string; // uuid型（文字列として扱う）
          current_lesson: number;
          total_lessons_completed: number;
          total_points: number;
          streak: number;
          last_study_date: string;
          lesson_progress: any;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string; // uuid型
          current_lesson?: number;
          total_lessons_completed?: number;
          total_points?: number;
          streak?: number;
          last_study_date?: string;
          lesson_progress?: any;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          current_lesson?: number;
          total_lessons_completed?: number;
          total_points?: number;
          streak?: number;
          last_study_date?: string;
          lesson_progress?: any;
          updated_at?: string;
        };
      };
    };
  };
};
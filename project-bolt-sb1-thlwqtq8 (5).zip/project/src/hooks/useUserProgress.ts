import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import type { UserProgress } from '../App';

export const useUserProgress = () => {
  const { user } = useAuth();
  const [userProgress, setUserProgress] = useState<UserProgress | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // ユーザー進捗データの取得
  const fetchUserProgress = async (userId: string) => {
    try {
      console.log('ユーザー進捗取得開始:', userId);
      setLoading(true);
      setError(null);

      // タイムアウト付きでデータ取得
      const progressPromise = supabase
        .from('user_progress')
        .select('*')
        .eq('user_id', userId)
        .single();

      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error('進捗データの取得がタイムアウトしました')), 15000);
      });

      const { data, error } = await Promise.race([
        progressPromise,
        timeoutPromise
      ]) as any;

      if (error) {
        // データが存在しない場合は初期データを作成
        if (error.code === 'PGRST116') {
          console.log('進捗データが存在しないため、初期データを作成します');
          
          const initialProgress: Omit<UserProgress, 'userId'> = {
            currentLesson: 1,
            totalLessonsCompleted: 0,
            totalPoints: 0,
            streak: 0,
            lastStudyDate: new Date().toISOString(),
            lessonProgress: []
          };

          const { data: newData, error: insertError } = await supabase
            .from('user_progress')
            .insert({
              user_id: userId,
              current_lesson: initialProgress.currentLesson,
              total_lessons_completed: initialProgress.totalLessonsCompleted,
              total_points: initialProgress.totalPoints,
              streak: initialProgress.streak,
              last_study_date: initialProgress.lastStudyDate,
              lesson_progress: initialProgress.lessonProgress
            })
            .select()
            .single();

          if (insertError) {
            console.error('初期進捗データ作成エラー:', insertError);
            throw insertError;
          }

          console.log('初期進捗データ作成成功');
          setUserProgress({ userId, ...initialProgress });
        } else {
          console.error('進捗データ取得エラー:', error);
          throw error;
        }
      } else {
        // データベースのカラム名をアプリの型に変換
        const progress: UserProgress = {
          userId: data.user_id,
          currentLesson: data.current_lesson,
          totalLessonsCompleted: data.total_lessons_completed,
          totalPoints: data.total_points,
          streak: data.streak,
          lastStudyDate: data.last_study_date,
          lessonProgress: data.lesson_progress || []
        };
        
        console.log('進捗データ取得成功:', progress);
        setUserProgress(progress);
      }
    } catch (err: any) {
      console.error('Error fetching user progress:', err);
      setError(err.message || 'ユーザー進捗の取得に失敗しました');
      
      // エラーが発生した場合でも基本的な進捗データを設定
      const fallbackProgress: UserProgress = {
        userId,
        currentLesson: 1,
        totalLessonsCompleted: 0,
        totalPoints: 0,
        streak: 0,
        lastStudyDate: new Date().toISOString(),
        lessonProgress: []
      };
      setUserProgress(fallbackProgress);
    } finally {
      setLoading(false);
    }
  };

  // ユーザー進捗データの更新
  const updateUserProgress = async (updates: Partial<UserProgress>) => {
    if (!user || !userProgress) {
      throw new Error('ユーザーがログインしていません');
    }

    try {
      setError(null);

      // アプリの型をデータベースのカラム名に変換
      const dbUpdates: any = {};
      if (updates.currentLesson !== undefined) dbUpdates.current_lesson = updates.currentLesson;
      if (updates.totalLessonsCompleted !== undefined) dbUpdates.total_lessons_completed = updates.totalLessonsCompleted;
      if (updates.totalPoints !== undefined) dbUpdates.total_points = updates.totalPoints;
      if (updates.streak !== undefined) dbUpdates.streak = updates.streak;
      if (updates.lastStudyDate !== undefined) dbUpdates.last_study_date = updates.lastStudyDate;
      if (updates.lessonProgress !== undefined) dbUpdates.lesson_progress = updates.lessonProgress;

      const { data, error } = await supabase
        .from('user_progress')
        .update(dbUpdates)
        .eq('user_id', user.id)
        .select()
        .single();

      if (error) {
        throw error;
      }

      // ローカル状態を更新
      const updatedProgress: UserProgress = {
        userId: data.user_id,
        currentLesson: data.current_lesson,
        totalLessonsCompleted: data.total_lessons_completed,
        totalPoints: data.total_points,
        streak: data.streak,
        lastStudyDate: data.last_study_date,
        lessonProgress: data.lesson_progress || []
      };

      setUserProgress(updatedProgress);
      return updatedProgress;
    } catch (err: any) {
      console.error('Error updating user progress:', err);
      setError(err.message || 'ユーザー進捗の更新に失敗しました');
      throw err;
    }
  };

  // ユーザーが変更された時に進捗データを取得
  useEffect(() => {
    let mounted = true;

    if (user) {
      fetchUserProgress(user.id).finally(() => {
        if (mounted) {
          console.log('進捗データ取得処理完了');
        }
      });
    } else {
      setUserProgress(null);
      setLoading(false);
      setError(null);
    }

    return () => {
      mounted = false;
    };
  }, [user]);

  return {
    userProgress,
    loading,
    error,
    updateUserProgress,
    refetch: () => user && fetchUserProgress(user.id)
  };
};
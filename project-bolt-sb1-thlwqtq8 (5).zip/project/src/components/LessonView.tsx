import React, { useState, useEffect } from 'react';
import { ArrowLeft, Play, Pause, Volume2, CheckCircle, RotateCcw } from 'lucide-react';
import { UserProgress } from '../App';
import { getLessonById, Lesson } from '../data/lessons';
import { VideoSection } from './lesson/VideoSection';
import { QuizSection } from './lesson/QuizSection';
import { RhythmSection } from './lesson/RhythmSection';
import { VocabularySection } from './lesson/VocabularySection';
import { PronunciationSection } from './lesson/PronunciationSection';
import { LessonComplete } from './lesson/LessonComplete';

type LessonStep = 'video' | 'quiz' | 'rhythm' | 'vocabulary' | 'pronunciation' | 'complete';

interface LessonViewProps {
  lessonId: number;
  userProgress: UserProgress | null;
  onCompleteLesson: (lessonId: number, score: number) => void;
  onBack: () => void;
}

export const LessonView: React.FC<LessonViewProps> = ({
  lessonId,
  userProgress,
  onCompleteLesson,
  onBack
}) => {
  const [currentStep, setCurrentStep] = useState<LessonStep>('video');
  const [stepScores, setStepScores] = useState<Record<string, number>>({});
  const [lesson, setLesson] = useState<Lesson | null>(null);

  useEffect(() => {
    const lessonData = getLessonById(lessonId);
    setLesson(lessonData || null);
  }, [lessonId]);

  const steps: { id: LessonStep; label: string; labelJapanese: string }[] = [
    { id: 'video', label: 'Video', labelJapanese: '動画' },
    { id: 'quiz', label: 'Quiz', labelJapanese: 'クイズ' },
    { id: 'rhythm', label: 'Rhythm', labelJapanese: 'リズム' },
    { id: 'vocabulary', label: 'Vocabulary', labelJapanese: '単語' },
    { id: 'pronunciation', label: 'Pronunciation', labelJapanese: '発音' },
  ];

  const getCurrentStepIndex = () => {
    return steps.findIndex(step => step.id === currentStep);
  };

  const handleStepComplete = (step: LessonStep, score: number) => {
    setStepScores(prev => ({ ...prev, [step]: score }));
    
    const currentIndex = getCurrentStepIndex();
    if (currentIndex < steps.length - 1) {
      setCurrentStep(steps[currentIndex + 1].id);
    } else {
      setCurrentStep('complete');
    }
  };

  const handleLessonComplete = () => {
    const totalScore = Object.values(stepScores).reduce((sum, score) => sum + score, 0);
    const averageScore = Math.round(totalScore / Object.keys(stepScores).length);
    onCompleteLesson(lessonId, averageScore);
  };

  const renderCurrentStep = () => {
    if (!lesson) return null;

    switch (currentStep) {
      case 'video':
        return (
          <VideoSection
            lesson={lesson}
            onComplete={(score) => handleStepComplete('video', score)}
          />
        );
      case 'quiz':
        return (
          <QuizSection
            lesson={lesson}
            onComplete={(score) => handleStepComplete('quiz', score)}
          />
        );
      case 'rhythm':
        return (
          <RhythmSection
            lesson={lesson}
            onComplete={(score) => handleStepComplete('rhythm', score)}
          />
        );
      case 'vocabulary':
        return (
          <VocabularySection
            lesson={lesson}
            onComplete={(score) => handleStepComplete('vocabulary', score)}
          />
        );
      case 'pronunciation':
        return (
          <PronunciationSection
            lesson={lesson}
            onComplete={(score) => handleStepComplete('pronunciation', score)}
          />
        );
      case 'complete':
        return (
          <LessonComplete
            lesson={lesson}
            scores={stepScores}
            onComplete={handleLessonComplete}
          />
        );
      default:
        return null;
    }
  };

  if (!lesson) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-600">レッスンを読み込み中...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={onBack}
            className="p-2 text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-slate-800">{lesson.titleJapanese}</h1>
            <p className="text-slate-600">{lesson.title}</p>
          </div>
        </div>
        
        <div className="text-right">
          <p className="text-sm text-slate-500">レッスン {lesson.id}</p>
          <p className="text-xs text-slate-400">レベル {lesson.level}</p>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="bg-white rounded-xl p-4 shadow-sm border">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm font-medium text-slate-700">学習進捗</span>
          <span className="text-sm text-slate-500">
            {currentStep === 'complete' ? '完了' : `${getCurrentStepIndex() + 1} / ${steps.length}`}
          </span>
        </div>
        
        <div className="flex space-x-2 mb-3">
          {steps.map((step, index) => (
            <div
              key={step.id}
              className={`flex-1 h-2 rounded-full transition-all ${
                index < getCurrentStepIndex() || currentStep === 'complete'
                  ? 'bg-green-400'
                  : index === getCurrentStepIndex()
                  ? 'bg-blue-400'
                  : 'bg-slate-200'
              }`}
            />
          ))}
        </div>
        
        <div className="flex justify-between text-xs text-slate-500">
          {steps.map((step) => (
            <span key={step.id} className="text-center">
              {step.labelJapanese}
            </span>
          ))}
        </div>
      </div>

      {/* Current Step Content */}
      <div className="bg-white rounded-xl shadow-sm border min-h-96">
        {renderCurrentStep()}
      </div>
    </div>
  );
};
import React from 'react';
import { Play, Lock, CheckCircle, Star, Clock, Target, TrendingUp } from 'lucide-react';
import { User, UserProgress } from '../App';
import { lessons } from '../data/lessons';

interface DashboardProps {
  user: User | null;
  userProgress: UserProgress | null;
  onStartLesson: (lessonId: number) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ user, userProgress, onStartLesson }) => {
  const getCompletedLessons = () => {
    return userProgress?.lessonProgress?.filter(p => p.completed).length || 0;
  };

  // Remove the lesson locking logic - all lessons are now unlocked
  const isLessonUnlocked = (lessonId: number) => {
    return true; // All lessons are always unlocked
  };

  const isLessonCompleted = (lessonId: number) => {
    return userProgress?.lessonProgress?.some(p => p.lessonId === lessonId && p.completed) || false;
  };

  const getLessonScore = (lessonId: number) => {
    const progress = userProgress?.lessonProgress?.find(p => p.lessonId === lessonId);
    return progress?.score || 0;
  };

  const stats = [
    {
      label: '完了レッスン',
      value: getCompletedLessons(),
      total: lessons.length,
      icon: CheckCircle,
      color: 'text-green-600',
      bgColor: 'bg-green-100'
    },
    {
      label: '獲得ポイント',
      value: user?.totalPoints || 0,
      icon: Star,
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-100'
    },
    {
      label: '学習ストリーク',
      value: `${userProgress?.streak || 0}日`,
      icon: Target,
      color: 'text-orange-600',
      bgColor: 'bg-orange-100'
    },
    {
      label: '現在のレベル',
      value: user?.level || 1,
      icon: TrendingUp,
      color: 'text-purple-600',
      bgColor: 'bg-purple-100'
    }
  ];

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="text-center py-8">
        <h1 className="text-4xl font-bold text-slate-800 mb-4">
          おかえりなさい、{user?.name || 'ゲスト'}さん！
        </h1>
        <p className="text-xl text-slate-600 mb-6">
          今日も英語学習を続けましょう
        </p>
        <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-blue-100 to-indigo-100 px-6 py-3 rounded-full">
          <Clock className="w-5 h-5 text-blue-600" />
          <span className="text-sm font-medium text-slate-700">
            すべてのレッスンにアクセス可能です！好きなレッスンから始めましょう
          </span>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-xl p-4 shadow-sm border border-slate-200">
              <div className="flex items-center justify-between mb-2">
                <div className={`w-10 h-10 ${stat.bgColor} rounded-lg flex items-center justify-center`}>
                  <Icon className={`w-5 h-5 ${stat.color}`} />
                </div>
              </div>
              <p className="text-2xl font-bold text-slate-800">
                {typeof stat.value === 'number' && 'total' in stat 
                  ? `${stat.value}/${stat.total}` 
                  : stat.value}
              </p>
              <p className="text-sm text-slate-500">{stat.label}</p>
            </div>
          );
        })}
      </div>

      {/* Current Progress */}
      <div className="bg-gradient-to-r from-blue-500 to-indigo-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-xl font-semibold mb-2">学習進捗</h3>
            <p className="text-blue-100">
              {getCompletedLessons()} / {lessons.length} レッスン完了
            </p>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold">
              {Math.round((getCompletedLessons() / lessons.length) * 100)}%
            </div>
            <div className="text-sm text-blue-100">完了率</div>
          </div>
        </div>
        <div className="w-full bg-white/20 rounded-full h-3">
          <div 
            className="bg-white rounded-full h-3 transition-all duration-500"
            style={{ width: `${(getCompletedLessons() / lessons.length) * 100}%` }}
          />
        </div>
      </div>

      {/* Lessons */}
      <div>
        <h2 className="text-2xl font-bold text-slate-800 mb-6">レッスン一覧</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {lessons.map((lesson) => {
            const isUnlocked = isLessonUnlocked(lesson.id);
            const isCompleted = isLessonCompleted(lesson.id);
            const score = getLessonScore(lesson.id);

            return (
              <div
                key={lesson.id}
                className={`bg-white rounded-xl p-6 shadow-sm border-2 transition-all duration-200 cursor-pointer hover:shadow-md ${
                  isCompleted
                    ? 'border-green-200 bg-green-50 hover:border-green-300'
                    : 'border-slate-200 hover:border-blue-200'
                }`}
                onClick={() => onStartLesson(lesson.id)}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <span className="bg-blue-100 text-blue-700 text-xs font-medium px-2 py-1 rounded-full">
                        レッスン {lesson.id}
                      </span>
                      <span className={`text-xs font-medium px-2 py-1 rounded-full ${
                        lesson.level === 1 ? 'bg-green-100 text-green-700' :
                        lesson.level === 2 ? 'bg-yellow-100 text-yellow-700' :
                        'bg-red-100 text-red-700'
                      }`}>
                        レベル {lesson.level}
                      </span>
                      {isCompleted && (
                        <div className="flex items-center space-x-1">
                          <CheckCircle className="w-4 h-4 text-green-500" />
                          <span className="text-xs text-green-600 font-medium">
                            {score}点
                          </span>
                        </div>
                      )}
                    </div>
                    <h3 className="text-lg font-semibold text-slate-800 mb-1">
                      {lesson.titleJapanese}
                    </h3>
                    <p className="text-sm text-slate-500 mb-2">{lesson.title}</p>
                    <p className="text-sm text-slate-600">{lesson.description}</p>
                  </div>
                  
                  <div className="ml-4">
                    {isCompleted ? (
                      <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                        <CheckCircle className="w-6 h-6 text-green-500" />
                      </div>
                    ) : (
                      <button className="w-12 h-12 bg-blue-500 hover:bg-blue-600 rounded-full flex items-center justify-center transition-colors">
                        <Play className="w-6 h-6 text-white ml-1" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Lesson Content Preview */}
                <div className="grid grid-cols-2 gap-4 text-xs text-slate-500 mb-3">
                  <div>
                    <span className="font-medium">文法:</span> {lesson.grammarPoints.length}項目
                  </div>
                  <div>
                    <span className="font-medium">単語:</span> {lesson.vocabulary.length}語
                  </div>
                </div>

                {/* Progress Indicators - Show for all lessons */}
                <div className="flex space-x-2">
                  {['動画', 'クイズ', 'リズム', '単語', '発音'].map((step, index) => (
                    <div
                      key={step}
                      className={`flex-1 h-2 rounded-full ${
                        isCompleted
                          ? 'bg-green-300'
                          : 'bg-slate-200'
                      }`}
                    />
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Next Steps */}
      <div className="bg-gradient-to-r from-orange-400 to-pink-400 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold mb-2">学習のヒント</h3>
            <p className="text-orange-100">
              {getCompletedLessons() === 0 
                ? 'どのレッスンからでも始められます！興味のあるトピックを選んでください'
                : getCompletedLessons() === lessons.length
                ? 'すべてのレッスンが完了しました！復習や苦手な分野の再学習をおすすめします'
                : '順番通りでなくても大丈夫！気になるレッスンから挑戦してみましょう'
              }
            </p>
          </div>
          <Target className="w-12 h-12 text-orange-200" />
        </div>
      </div>
    </div>
  );
};
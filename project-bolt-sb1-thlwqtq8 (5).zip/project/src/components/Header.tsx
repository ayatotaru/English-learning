import React, { useState } from 'react';
import { Home, BarChart3, User, BookOpen, LogIn, LogOut } from 'lucide-react';
import { ViewType, User as UserType } from '../App';
import { useAuth } from '../contexts/AuthContext';
import { AuthModal } from './auth/AuthModal';

interface HeaderProps {
  currentView: ViewType;
  onViewChange: (view: ViewType) => void;
  user: UserType | null;
}

export const Header: React.FC<HeaderProps> = ({ currentView, onViewChange, user }) => {
  const { user: authUser, signOut, loading } = useAuth();
  const [showAuthModal, setShowAuthModal] = useState(false);

  const navItems = [
    { id: 'dashboard' as ViewType, label: 'ホーム', icon: Home },
    { id: 'progress' as ViewType, label: '進捗', icon: BarChart3 },
    { id: 'profile' as ViewType, label: 'プロフィール', icon: User },
  ];

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Sign out error:', error);
    }
  };

  return (
    <>
      <header className="bg-white/95 backdrop-blur-lg border-b border-slate-200 sticky top-0 z-50 shadow-sm">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                  English Master
                </h1>
                <p className="text-xs text-slate-500">初級編</p>
              </div>
            </div>
            
            {/* Navigation - Only show when user is authenticated */}
            {authUser && (
              <nav className="hidden md:flex items-center space-x-2">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => onViewChange(item.id)}
                      className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-all duration-200 ${
                        currentView === item.id
                          ? 'bg-blue-100 text-blue-700 font-medium'
                          : 'text-slate-600 hover:text-blue-600 hover:bg-slate-100'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span className="text-sm">{item.label}</span>
                    </button>
                  );
                })}
              </nav>
            )}

            {/* Mobile Navigation - Only show when user is authenticated */}
            {authUser && (
              <nav className="flex md:hidden items-center space-x-1">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => onViewChange(item.id)}
                      className={`flex items-center justify-center p-2 rounded-lg transition-all duration-200 ${
                        currentView === item.id
                          ? 'bg-blue-100 text-blue-700'
                          : 'text-slate-600 hover:text-blue-600 hover:bg-slate-100'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </button>
                  );
                })}
              </nav>
            )}

            {/* Login/Logout Button */}
            <div className="flex items-center">
              {loading ? (
                <div className="w-8 h-8 bg-slate-200 rounded-lg animate-pulse"></div>
              ) : (
                <>
                  {authUser ? (
                    <button
                      onClick={handleSignOut}
                      className="flex items-center space-x-2 bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg font-medium transition-colors"
                    >
                      <LogOut className="w-4 h-4" />
                      <span className="hidden sm:inline">ログアウト</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => setShowAuthModal(true)}
                      className="flex items-center space-x-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg font-medium transition-colors"
                    >
                      <LogIn className="w-4 h-4" />
                      <span className="hidden sm:inline">ログイン</span>
                    </button>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Auth Modal */}
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        initialMode="signin"
      />
    </>
  );
};
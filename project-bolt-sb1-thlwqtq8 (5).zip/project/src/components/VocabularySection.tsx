import React, { useState, useEffect } from 'react';
import { RotateCcw, Volume2, Check, X, Star } from 'lucide-react';
import { StudyProgress } from '../App';

interface VocabularyItem {
  id: number;
  english: string;
  japanese: string;
  furigana: string;
  romaji: string;
  pronunciation: string;
  example: string;
  exampleJapanese: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  category: string;
}

interface VocabularyProps {
  progress: StudyProgress;
  updateProgress: (progress: Partial<StudyProgress>) => void;
}

export const VocabularySection: React.FC<VocabularyProps> = ({ progress, updateProgress }) => {
  const [currentCard, setCurrentCard] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [studiedCards, setStudiedCards] = useState<Set<number>>(new Set());

  const vocabularyData: VocabularyItem[] = [
    {
      id: 1,
      english: "Hello",
      japanese: "こんにちは",
      furigana: "こんにちは",
      romaji: "konnichiwa",
      pronunciation: "/həˈloʊ/",
      example: "Hello, nice to meet you!",
      exampleJapanese: "こんにちは、はじめまして！",
      difficulty: "beginner",
      category: "greetings"
    },
    {
      id: 2,
      english: "Beautiful",
      japanese: "美しい",
      furigana: "うつくしい",
      romaji: "utsukushii",
      pronunciation: "/ˈbjuːtɪfəl/",
      example: "The sunset is beautiful.",
      exampleJapanese: "夕日が美しいです。",
      difficulty: "beginner",
      category: "adjectives"
    },
    {
      id: 3,
      english: "Opportunity",
      japanese: "機会",
      furigana: "きかい",
      romaji: "kikai",
      pronunciation: "/ˌɑːpərˈtuːnəti/",
      example: "This is a great opportunity to learn.",
      exampleJapanese: "これは学ぶ素晴らしい機会です。",
      difficulty: "intermediate",
      category: "business"
    },
    {
      id: 4,
      english: "Appreciate",
      japanese: "感謝する",
      furigana: "かんしゃする",
      romaji: "kansha suru",
      pronunciation: "/əˈpriːʃieɪt/",
      example: "I appreciate your help.",
      exampleJapanese: "あなたの助けに感謝します。",
      difficulty: "intermediate",
      category: "emotions"
    },
    {
      id: 5,
      english: "Environment",
      japanese: "環境",
      furigana: "かんきょう",
      romaji: "kankyou",
      pronunciation: "/ɪnˈvaɪrənmənt/",
      example: "We must protect the environment.",
      exampleJapanese: "私たちは環境を守らなければなりません。",
      difficulty: "advanced",
      category: "science"
    }
  ];

  const categories = [
    { id: 'all', label: 'すべて', color: 'bg-slate-100 text-slate-700' },
    { id: 'greetings', label: '挨拶', color: 'bg-blue-100 text-blue-700' },
    { id: 'adjectives', label: '形容詞', color: 'bg-green-100 text-green-700' },
    { id: 'business', label: 'ビジネス', color: 'bg-purple-100 text-purple-700' },
    { id: 'emotions', label: '感情', color: 'bg-pink-100 text-pink-700' },
    { id: 'science', label: '科学', color: 'bg-teal-100 text-teal-700' }
  ];

  const filteredVocabulary = selectedCategory === 'all' 
    ? vocabularyData 
    : vocabularyData.filter(item => item.category === selectedCategory);

  const currentItem = filteredVocabulary[currentCard];

  const handleNext = () => {
    setIsFlipped(false);
    setCurrentCard((prev) => (prev + 1) % filteredVocabulary.length);
  };

  const handlePrevious = () => {
    setIsFlipped(false);
    setCurrentCard((prev) => (prev - 1 + filteredVocabulary.length) % filteredVocabulary.length);
  };

  const handleStudied = (isCorrect: boolean) => {
    if (isCorrect && !studiedCards.has(currentItem.id)) {
      setStudiedCards(prev => new Set([...prev, currentItem.id]));
      updateProgress({ 
        vocabularyStudied: progress.vocabularyStudied + 1,
        totalStudyTime: progress.totalStudyTime + 2
      });
    }
    handleNext();
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'bg-green-100 text-green-700';
      case 'intermediate': return 'bg-yellow-100 text-yellow-700';
      case 'advanced': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  if (!currentItem) return <div>Loading...</div>;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold text-slate-800 mb-2">単語学習</h2>
        <p className="text-slate-600">フラッシュカードで英単語を覚えよう</p>
      </div>

      {/* Category Filter */}
      <div className="flex flex-wrap gap-2 justify-center">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => {
              setSelectedCategory(category.id);
              setCurrentCard(0);
              setIsFlipped(false);
            }}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
              selectedCategory === category.id 
                ? category.color + ' shadow-sm' 
                : 'bg-white text-slate-600 hover:bg-slate-50'
            }`}
          >
            {category.label}
          </button>
        ))}
      </div>

      {/* Progress */}
      <div className="text-center">
        <div className="inline-flex items-center space-x-4 bg-white rounded-lg px-6 py-3 shadow-sm border">
          <span className="text-sm text-slate-600">
            {currentCard + 1} / {filteredVocabulary.length}
          </span>
          <div className="w-32 bg-slate-200 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all"
              style={{ width: `${((currentCard + 1) / filteredVocabulary.length) * 100}%` }}
            />
          </div>
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(currentItem.difficulty)}`}>
            {currentItem.difficulty}
          </span>
        </div>
      </div>

      {/* Flashcard */}
      <div className="flex justify-center">
        <div 
          className="relative w-96 h-64 cursor-pointer perspective-1000"
          onClick={() => setIsFlipped(!isFlipped)}
        >
          <div className={`absolute inset-0 w-full h-full transition-transform duration-600 transform-style-preserve-3d ${isFlipped ? 'rotate-y-180' : ''}`}>
            {/* Front */}
            <div className="absolute inset-0 w-full h-full backface-hidden bg-white rounded-xl shadow-lg border-2 border-slate-200 flex flex-col items-center justify-center p-6">
              <div className="text-center space-y-4">
                <h3 className="text-4xl font-bold text-slate-800">{currentItem.english}</h3>
                <p className="text-lg text-slate-500">{currentItem.pronunciation}</p>
                <div className="flex items-center justify-center space-x-2">
                  <Volume2 className="w-5 h-5 text-blue-500" />
                  <span className="text-sm text-slate-600">クリックして裏面を見る</span>
                </div>
              </div>
            </div>

            {/* Back */}
            <div className="absolute inset-0 w-full h-full backface-hidden bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl shadow-lg border-2 border-blue-200 rotate-y-180 flex flex-col justify-center p-6">
              <div className="text-center space-y-3">
                <h3 className="text-3xl font-bold text-slate-800">{currentItem.japanese}</h3>
                <p className="text-lg text-slate-600">{currentItem.furigana}</p>
                <p className="text-base text-slate-500">{currentItem.romaji}</p>
                <div className="border-t border-slate-300 pt-3 mt-4">
                  <p className="text-sm font-medium text-slate-700">{currentItem.example}</p>
                  <p className="text-sm text-slate-600 mt-1">{currentItem.exampleJapanese}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="flex justify-center items-center space-x-4">
        <button
          onClick={handlePrevious}
          className="p-3 bg-white rounded-full shadow-sm border border-slate-200 hover:shadow-md transition-all text-slate-600 hover:text-slate-800"
        >
          <RotateCcw className="w-5 h-5" />
        </button>

        {isFlipped && (
          <>
            <button
              onClick={() => handleStudied(false)}
              className="flex items-center space-x-2 px-6 py-3 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
            >
              <X className="w-5 h-5" />
              <span>難しい</span>
            </button>

            <button
              onClick={() => handleStudied(true)}
              className="flex items-center space-x-2 px-6 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
            >
              <Check className="w-5 h-5" />
              <span>簡単</span>
            </button>
          </>
        )}

        <button
          onClick={handleNext}
          className="p-3 bg-blue-500 text-white rounded-full shadow-sm hover:bg-blue-600 transition-all"
        >
          <Star className="w-5 h-5" />
        </button>
      </div>

      {/* Study Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
        <div className="bg-white rounded-lg p-4 shadow-sm border text-center">
          <div className="text-2xl font-bold text-blue-600">{studiedCards.size}</div>
          <div className="text-sm text-slate-600">今日学習した単語</div>
        </div>
        <div className="bg-white rounded-lg p-4 shadow-sm border text-center">
          <div className="text-2xl font-bold text-green-600">{progress.vocabularyStudied}</div>
          <div className="text-sm text-slate-600">総学習単語数</div>
        </div>
        <div className="bg-white rounded-lg p-4 shadow-sm border text-center">
          <div className="text-2xl font-bold text-purple-600">{Math.round((studiedCards.size / filteredVocabulary.length) * 100)}%</div>
          <div className="text-sm text-slate-600">今日の進捗</div>
        </div>
      </div>
    </div>
  );
};
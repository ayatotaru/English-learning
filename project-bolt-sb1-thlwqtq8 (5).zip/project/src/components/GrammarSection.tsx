import React, { useState } from 'react';
import { CheckCircle, Circle, BookOpen, Lightbulb, ArrowRight } from 'lucide-react';
import { StudyProgress } from '../App';

interface GrammarLesson {
  id: number;
  title: string;
  titleJapanese: string;
  level: 'beginner' | 'intermediate' | 'advanced';
  description: string;
  rules: {
    english: string;
    japanese: string;
    examples: { english: string; japanese: string; }[];
  }[];
  tips: string[];
  exercises: {
    question: string;
    options: string[];
    correct: number;
    explanation: string;
  }[];
}

interface GrammarSectionProps {
  progress: StudyProgress;
  updateProgress: (progress: Partial<StudyProgress>) => void;
}

export const GrammarSection: React.FC<GrammarSectionProps> = ({ progress, updateProgress }) => {
  const [selectedLesson, setSelectedLesson] = useState<number | null>(null);
  const [completedLessons, setCompletedLessons] = useState<Set<number>>(new Set());
  const [currentExercise, setCurrentExercise] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);

  const grammarLessons: GrammarLesson[] = [
    {
      id: 1,
      title: "Present Simple Tense",
      titleJapanese: "現在形",
      level: "beginner",
      description: "日常的な習慣や一般的な事実を表現する基本的な時制",
      rules: [
        {
          english: "Use present simple for habits, routines, and general facts",
          japanese: "習慣、日課、一般的な事実を表現する時に使用",
          examples: [
            { english: "I drink coffee every morning.", japanese: "私は毎朝コーヒーを飲みます。" },
            { english: "She works at a bank.", japanese: "彼女は銀行で働いています。" }
          ]
        },
        {
          english: "Add 's' or 'es' to verbs with he/she/it",
          japanese: "he/she/itの時は動詞にsまたはesを付ける",
          examples: [
            { english: "He plays tennis on weekends.", japanese: "彼は週末にテニスをします。" },
            { english: "She watches TV every evening.", japanese: "彼女は毎晩テレビを見ます。" }
          ]
        }
      ],
      tips: [
        "頻度を表す副詞（always, usually, often, sometimes, never）は動詞の前に置く",
        "疑問文ではDo/Doesを使い、否定文ではdon't/doesn'tを使う",
        "時間や頻度を表す語句と一緒によく使われる"
      ],
      exercises: [
        {
          question: "She _____ to work by train every day.",
          options: ["go", "goes", "going", "went"],
          correct: 1,
          explanation: "三人称単数（She）なので、動詞にsを付けて'goes'になります。"
        },
        {
          question: "_____ you like pizza?",
          options: ["Does", "Do", "Are", "Is"],
          correct: 1,
          explanation: "youに対する疑問文なので'Do'を使います。"
        }
      ]
    },
    {
      id: 2,
      title: "Past Simple Tense",
      titleJapanese: "過去形",
      level: "beginner",
      description: "過去に完了した出来事や状態を表現する時制",
      rules: [
        {
          english: "Use past simple for completed actions in the past",
          japanese: "過去に完了した動作を表現する時に使用",
          examples: [
            { english: "I visited Tokyo last year.", japanese: "私は去年東京を訪れました。" },
            { english: "They finished their homework yesterday.", japanese: "彼らは昨日宿題を終えました。" }
          ]
        }
      ],
      tips: [
        "規則動詞は語尾に-edを付ける",
        "不規則動詞は特別な形を覚える必要がある",
        "過去の時間を表す語句（yesterday, last week, ago）と一緒に使われる"
      ],
      exercises: [
        {
          question: "I _____ a movie last night.",
          options: ["watch", "watched", "watching", "watches"],
          correct: 1,
          explanation: "過去形なので'watched'が正解です。"
        }
      ]
    }
  ];

  const handleLessonComplete = (lessonId: number) => {
    if (!completedLessons.has(lessonId)) {
      setCompletedLessons(prev => new Set([...prev, lessonId]));
      updateProgress({
        grammarLessons: progress.grammarLessons + 1,
        totalStudyTime: progress.totalStudyTime + 10
      });
    }
  };

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
    setShowExplanation(true);
  };

  const nextExercise = () => {
    const lesson = grammarLessons.find(l => l.id === selectedLesson);
    if (lesson && currentExercise < lesson.exercises.length - 1) {
      setCurrentExercise(currentExercise + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
    } else {
      if (selectedLesson) handleLessonComplete(selectedLesson);
      setSelectedLesson(null);
      setCurrentExercise(0);
      setSelectedAnswer(null);
      setShowExplanation(false);
    }
  };

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'beginner': return 'bg-green-100 text-green-700';
      case 'intermediate': return 'bg-yellow-100 text-yellow-700';
      case 'advanced': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  if (selectedLesson) {
    const lesson = grammarLessons.find(l => l.id === selectedLesson)!;
    const currentEx = lesson.exercises[currentExercise];

    return (
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <button
            onClick={() => setSelectedLesson(null)}
            className="p-2 text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-all"
          >
            <ArrowRight className="w-5 h-5 rotate-180" />
          </button>
          <div>
            <h2 className="text-2xl font-bold text-slate-800">{lesson.titleJapanese}</h2>
            <p className="text-slate-600">{lesson.title}</p>
          </div>
        </div>

        {/* Lesson Content */}
        <div className="space-y-6">
          {/* Rules */}
          <div className="bg-white rounded-xl p-6 shadow-sm border">
            <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center">
              <BookOpen className="w-5 h-5 mr-2 text-blue-500" />
              文法ルール
            </h3>
            <div className="space-y-6">
              {lesson.rules.map((rule, index) => (
                <div key={index} className="space-y-3">
                  <div className="bg-blue-50 rounded-lg p-4">
                    <p className="font-medium text-blue-800">{rule.english}</p>
                    <p className="text-blue-600 text-sm mt-1">{rule.japanese}</p>
                  </div>
                  <div className="space-y-2">
                    {rule.examples.map((example, exIndex) => (
                      <div key={exIndex} className="pl-4 border-l-2 border-slate-200">
                        <p className="font-medium text-slate-800">{example.english}</p>
                        <p className="text-slate-600 text-sm">{example.japanese}</p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Tips */}
          <div className="bg-yellow-50 rounded-xl p-6 shadow-sm border border-yellow-200">
            <h3 className="text-lg font-semibold text-yellow-800 mb-4 flex items-center">
              <Lightbulb className="w-5 h-5 mr-2" />
              学習のコツ
            </h3>
            <ul className="space-y-2">
              {lesson.tips.map((tip, index) => (
                <li key={index} className="flex items-start space-x-2">
                  <Circle className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                  <span className="text-yellow-800">{tip}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Exercise */}
          <div className="bg-white rounded-xl p-6 shadow-sm border">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-slate-800">
                練習問題 {currentExercise + 1} / {lesson.exercises.length}
              </h3>
              <div className="w-32 bg-slate-200 rounded-full h-2">
                <div 
                  className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all"
                  style={{ width: `${((currentExercise + 1) / lesson.exercises.length) * 100}%` }}
                />
              </div>
            </div>

            <div className="space-y-4">
              <p className="text-lg font-medium text-slate-800">{currentEx.question}</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {currentEx.options.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => handleAnswerSelect(index)}
                    disabled={showExplanation}
                    className={`p-3 text-left rounded-lg border-2 transition-all ${
                      selectedAnswer === index
                        ? index === currentEx.correct
                          ? 'border-green-500 bg-green-50 text-green-800'
                          : 'border-red-500 bg-red-50 text-red-800'
                        : showExplanation && index === currentEx.correct
                        ? 'border-green-500 bg-green-50 text-green-800'
                        : 'border-slate-200 hover:border-blue-300 hover:bg-blue-50'
                    }`}
                  >
                    {option}
                  </button>
                ))}
              </div>

              {showExplanation && (
                <div className="bg-slate-50 rounded-lg p-4">
                  <p className="text-slate-700">{currentEx.explanation}</p>
                  <button
                    onClick={nextExercise}
                    className="mt-3 bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
                  >
                    {currentExercise < lesson.exercises.length - 1 ? '次の問題' : 'レッスン完了'}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold text-slate-800 mb-2">文法レッスン</h2>
        <p className="text-slate-600">基礎から応用まで英文法を体系的に学習</p>
      </div>

      {/* Progress Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-lg p-4 shadow-sm border text-center">
          <div className="text-2xl font-bold text-green-600">{completedLessons.size}</div>
          <div className="text-sm text-slate-600">完了レッスン</div>
        </div>
        <div className="bg-white rounded-lg p-4 shadow-sm border text-center">
          <div className="text-2xl font-bold text-blue-600">{progress.grammarLessons}</div>
          <div className="text-sm text-slate-600">総学習レッスン</div>
        </div>
        <div className="bg-white rounded-lg p-4 shadow-sm border text-center">
          <div className="text-2xl font-bold text-purple-600">{grammarLessons.length}</div>
          <div className="text-sm text-slate-600">利用可能レッスン</div>
        </div>
      </div>

      {/* Lessons Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {grammarLessons.map((lesson) => (
          <div
            key={lesson.id}
            className={`bg-white rounded-xl p-6 shadow-sm border-2 cursor-pointer transition-all duration-200 hover:shadow-md ${
              completedLessons.has(lesson.id)
                ? 'border-green-200 bg-green-50'
                : 'border-slate-200 hover:border-blue-200'
            }`}
            onClick={() => setSelectedLesson(lesson.id)}
          >
            <div className="space-y-4">
              <div className="flex items-start justify-between">
                <div className="space-y-2">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${getLevelColor(lesson.level)}`}>
                    {lesson.level}
                  </span>
                  <h3 className="text-xl font-bold text-slate-800">{lesson.titleJapanese}</h3>
                  <p className="text-sm text-slate-500">{lesson.title}</p>
                </div>
                {completedLessons.has(lesson.id) ? (
                  <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0" />
                ) : (
                  <Circle className="w-6 h-6 text-slate-300 flex-shrink-0" />
                )}
              </div>

              <p className="text-slate-600">{lesson.description}</p>

              <div className="flex items-center justify-between pt-4 border-t border-slate-200">
                <span className="text-sm text-slate-500">
                  {lesson.exercises.length} 練習問題
                </span>
                <ArrowRight className="w-4 h-4 text-blue-500" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { AuthModal } from './AuthModal';
import type { ProtectedRouteProps } from '../../types/auth';

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ 
  children, 
  fallback 
}) => {
  const { user, loading, error } = useAuth();
  const [showAuthModal, setShowAuthModal] = React.useState(false);
  const [showManualLogin, setShowManualLogin] = React.useState(false);

  // 5秒後に手動ログインオプションを表示（10秒から短縮）
  React.useEffect(() => {
    if (loading && !user) {
      const timer = setTimeout(() => {
        setShowManualLogin(true);
      }, 5000);
      
      return () => clearTimeout(timer);
    }
  }, [loading, user]);

  // ローディング中（5秒以内）
  if (loading && !showManualLogin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center max-w-md mx-auto">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-600 mb-2">認証状態を確認中...</p>
          <p className="text-slate-400 text-sm">
            初回アクセス時は少し時間がかかる場合があります
          </p>
          
          {/* 進捗バー */}
          <div className="w-full bg-slate-200 rounded-full h-2 mt-4">
            <div className="bg-blue-600 h-2 rounded-full animate-pulse" style={{ width: '60%' }}></div>
          </div>

          {/* デバッグ情報（開発環境のみ） */}
          {import.meta.env.DEV && (
            <div className="mt-4 p-3 bg-slate-100 rounded-lg text-left">
              <p className="text-xs text-slate-600 font-mono">
                Debug Info:<br/>
                URL: {import.meta.env.VITE_SUPABASE_URL ? '✓' : '✗'}<br/>
                Key: {import.meta.env.VITE_SUPABASE_ANON_KEY ? '✓' : '✗'}
              </p>
            </div>
          )}
        </div>
      </div>
    );
  }

  // エラーまたは長時間ローディング中、または未認証の場合
  if (error || showManualLogin || (!loading && !user)) {
    return fallback || (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        {/* Header with Login Button */}
        <header className="bg-white/95 backdrop-blur-lg border-b border-slate-200 sticky top-0 z-50 shadow-sm">
          <div className="container mx-auto px-4 max-w-6xl">
            <div className="flex items-center justify-between h-16">
              {/* Logo */}
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                  </svg>
                </div>
                <div>
                  <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                    English Master
                  </h1>
                  <p className="text-xs text-slate-500">初級編</p>
                </div>
              </div>
              
              {/* Login Button */}
              <button
                onClick={() => setShowAuthModal(true)}
                className="flex items-center space-x-2 bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded-lg font-medium transition-colors shadow-sm"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                </svg>
                <span>ログイン</span>
              </button>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
          <div className="text-center max-w-md mx-auto p-6">
            <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <svg className="w-10 h-10 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
              </svg>
            </div>
            
            <h2 className="text-3xl font-bold text-slate-800 mb-4">English Master へようこそ</h2>
            
            {error && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-700 text-sm mb-2">{error}</p>
                <button
                  onClick={() => window.location.reload()}
                  className="text-red-600 hover:text-red-800 text-sm underline"
                >
                  ページを再読み込み
                </button>
              </div>
            )}
            
            {showManualLogin && !error && (
              <div className="mb-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <p className="text-yellow-800 text-sm">
                  認証の初期化に時間がかかっています。<br />
                  下のボタンからログインしてください。
                </p>
              </div>
            )}
            
            <p className="text-slate-600 mb-8 leading-relaxed">
              英語学習を始めるには、まずアカウントにログインしてください。<br />
              個人の進捗を管理し、効果的な学習体験をお楽しみいただけます。
            </p>
            
            <button
              onClick={() => setShowAuthModal(true)}
              className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 rounded-lg font-medium transition-colors shadow-sm"
            >
              今すぐ始める
            </button>
            
            {/* トラブルシューティング */}
            <div className="mt-8 p-4 bg-slate-50 rounded-lg">
              <h3 className="text-sm font-medium text-slate-700 mb-2">ログインできない場合</h3>
              <div className="text-xs text-slate-600 space-y-1">
                <p>• ページを再読み込みしてください</p>
                <p>• ブラウザのキャッシュをクリアしてください</p>
                <p>• インターネット接続を確認してください</p>
                <p>• しばらく時間をおいて再度お試しください</p>
              </div>
            </div>

            {/* 開発環境でのデバッグ情報 */}
            {import.meta.env.DEV && (
              <div className="mt-4 p-3 bg-slate-100 rounded-lg text-left">
                <h4 className="text-xs font-medium text-slate-700 mb-2">開発者情報</h4>
                <div className="text-xs text-slate-600 font-mono space-y-1">
                  <p>Supabase URL: {import.meta.env.VITE_SUPABASE_URL ? '設定済み' : '未設定'}</p>
                  <p>Supabase Key: {import.meta.env.VITE_SUPABASE_ANON_KEY ? '設定済み' : '未設定'}</p>
                  <p>Error: {error || 'なし'}</p>
                  <p>Loading: {loading ? 'true' : 'false'}</p>
                  <p>Manual Login: {showManualLogin ? 'true' : 'false'}</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Auth Modal */}
        <AuthModal
          isOpen={showAuthModal}
          onClose={() => setShowAuthModal(false)}
          initialMode="signin"
        />
      </div>
    );
  }

  // 認証済みの場合、子コンポーネントを表示
  return <>{children}</>;
};
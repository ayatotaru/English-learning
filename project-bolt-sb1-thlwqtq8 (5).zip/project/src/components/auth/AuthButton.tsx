import React, { useState } from 'react';
import { LogIn, LogOut, User } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { AuthModal } from './AuthModal';

export const AuthButton: React.FC = () => {
  const { user, profile, signOut, loading } = useAuth();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  const handleSignOut = async () => {
    try {
      await signOut();
      setShowUserMenu(false);
    } catch (error) {
      console.error('Sign out error:', error);
    }
  };

  // ローディング中
  if (loading) {
    return (
      <div className="w-8 h-8 bg-slate-200 rounded-full animate-pulse"></div>
    );
  }

  // 未認証の場合
  if (!user) {
    return (
      <>
        <button
          onClick={() => setShowAuthModal(true)}
          className="flex items-center space-x-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg font-medium transition-colors"
        >
          <LogIn className="w-4 h-4" />
          <span className="hidden sm:inline">ログイン</span>
        </button>

        <AuthModal
          isOpen={showAuthModal}
          onClose={() => setShowAuthModal(false)}
          initialMode="signin"
        />
      </>
    );
  }

  // 認証済みの場合
  return (
    <div className="relative">
      <button
        onClick={() => setShowUserMenu(!showUserMenu)}
        className="flex items-center space-x-3 p-2 rounded-lg hover:bg-slate-100 transition-colors"
      >
        <div className="text-right hidden sm:block">
          <p className="text-sm font-medium text-slate-800">
            {profile?.full_name || user.email}
          </p>
          <p className="text-xs text-slate-500">
            {user.email}
          </p>
        </div>
        
        {profile?.avatar_url ? (
          <img
            src={profile.avatar_url}
            alt="Profile"
            className="w-8 h-8 rounded-full object-cover"
          />
        ) : (
          <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
            <span className="text-white text-sm font-bold">
              {(profile?.full_name || user.email || 'U').charAt(0).toUpperCase()}
            </span>
          </div>
        )}
      </button>

      {/* ユーザーメニュー */}
      {showUserMenu && (
        <>
          {/* オーバーレイ */}
          <div
            className="fixed inset-0 z-10"
            onClick={() => setShowUserMenu(false)}
          />
          
          {/* メニュー */}
          <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-lg shadow-lg border border-slate-200 py-2 z-20">
            <div className="px-4 py-2 border-b border-slate-200">
              <p className="text-sm font-medium text-slate-800">
                {profile?.full_name || 'ユーザー'}
              </p>
              <p className="text-xs text-slate-500">{user.email}</p>
            </div>
            
            <button
              onClick={() => {
                setShowUserMenu(false);
                // プロファイル編集機能は後で実装
              }}
              className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 flex items-center space-x-2"
            >
              <User className="w-4 h-4" />
              <span>プロファイル編集</span>
            </button>
            
            <button
              onClick={handleSignOut}
              className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 flex items-center space-x-2"
            >
              <LogOut className="w-4 h-4" />
              <span>ログアウト</span>
            </button>
          </div>
        </>
      )}
    </div>
  );
};
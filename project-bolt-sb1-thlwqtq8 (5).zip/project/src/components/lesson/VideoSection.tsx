import React from 'react';
import { Lesson } from '../../data/lessons';

interface VideoSectionProps {
  lesson: Lesson;
  onComplete: (score: number) => void;
}

export const VideoSection: React.FC<VideoSectionProps> = ({ lesson, onComplete }) => {
  return (
    <div className="p-8 space-y-6">
      {/* Video Header */}
      <div className="text-center">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">文法動画</h2>
        <p className="text-slate-600">{lesson.description}</p>
      </div>

      {/* YouTube動画埋め込み */}
      <div className="aspect-video max-w-3xl mx-auto">
        <iframe
          className="w-full h-full rounded-xl"
          src="https://www.youtube.com/embed/vZQOyapoNuI"
          title="文法解説動画"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
      </div>

      {/* Grammar Points */}
      <div className="bg-blue-50 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-blue-800 mb-4">この動画で学ぶ文法ポイント</h3>
        <ul className="space-y-2">
          {lesson.grammarPoints.map((point, index) => (
            <li key={index} className="flex items-start space-x-2">
              <div className="w-6 h-6 bg-blue-200 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-blue-700 text-sm font-medium">{index + 1}</span>
              </div>
              <span className="text-blue-800">{point}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Complete Button */}
      <div className="text-center">
        <button
          onClick={() => onComplete(100)}
          className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 rounded-lg font-medium transition-colors"
        >
          動画学習を完了してクイズに進む
        </button>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { Lesson } from '../../data/lessons';

interface RhythmSectionProps {
  lesson: Lesson;
  onComplete: (score: number) => void;
}

export const RhythmSection: React.FC<RhythmSectionProps> = ({ lesson, onComplete }) => {
  const [hasCompleted, setHasCompleted] = useState(false);

  const handleComplete = () => {
    onComplete(100);
    setHasCompleted(true);
  };

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">リズム学習</h2>
        <p className="text-slate-600">YouTube動画でリズムを身につけよう</p>
      </div>

      {/* YouTube Shorts 動画埋め込み */}
      <div className="w-full flex justify-center">
        <iframe
          width="320"
          height="560"
          src="https://www.youtube.com/embed/FgJVEduRM0Y"
          title="リズム練習ショート動画"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          className="rounded-xl"
        />
      </div>

      {/* フレーズ一覧 */}
      <div className="bg-blue-50 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-blue-800 mb-4">練習フレーズ</h3>
        <div className="space-y-3">
          {lesson.rhythmContent.phrases.map((phraseItem, index) => (
            <div
              key={index}
              className="p-3 rounded-lg bg-white border border-blue-200"
            >
              <p className="font-medium text-blue-800">{phraseItem.english}</p>
              <p className="text-sm text-blue-600">{phraseItem.japanese}</p>
            </div>
          ))}
        </div>
      </div>

      {/* 完了ボタン */}
      <div className="text-center">
        <button
          onClick={handleComplete}
          className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 rounded-lg font-medium transition-colors"
        >
          リズム学習を完了して次に進む
        </button>
      </div>

      {/* Tips */}
      <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
        <h4 className="font-medium text-yellow-800 mb-2">リズム学習のコツ</h4>
        <ul className="text-sm text-yellow-700 space-y-1">
          <li>• 英語のリズムを意識して声に出しましょう</li>
          <li>• 動画を何度も見て、耳と口を慣らしましょう</li>
        </ul>
      </div>
    </div>
  );
};

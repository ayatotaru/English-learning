import React, { useState } from 'react';
import { CheckCircle, XCircle, ArrowRight } from 'lucide-react';
import { Lesson } from '../../data/lessons';

interface QuizSectionProps {
  lesson: Lesson;
  onComplete: (score: number) => void;
}

export const QuizSection: React.FC<QuizSectionProps> = ({ lesson, onComplete }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [userAnswer, setUserAnswer] = useState('');
  const [showResult, setShowResult] = useState(false);
  const [answers, setAnswers] = useState<string[]>([]);
  const [isComplete, setIsComplete] = useState(false);

  const question = lesson.quiz[currentQuestion];
  const isLastQuestion = currentQuestion === lesson.quiz.length - 1;

  const handleSubmitAnswer = () => {
    if (userAnswer.trim() === '') return;
    
    setAnswers(prev => [...prev, userAnswer.trim()]);
    setShowResult(true);
  };

  const handleNextQuestion = () => {
    if (isLastQuestion) {
      // Calculate score
      const correctAnswers = answers.filter((answer, index) => 
        answer.toLowerCase() === lesson.quiz[index].correctAnswer.toLowerCase()
      ).length + (userAnswer.toLowerCase().trim() === question.correctAnswer.toLowerCase() ? 1 : 0);
      
      const score = Math.round((correctAnswers / lesson.quiz.length) * 100);
      setIsComplete(true);
      setTimeout(() => onComplete(score), 1500);
    } else {
      setCurrentQuestion(prev => prev + 1);
      setUserAnswer('');
      setShowResult(false);
    }
  };

  const isCorrect = userAnswer.toLowerCase().trim() === question.correctAnswer.toLowerCase();

  if (isComplete) {
    const correctAnswers = answers.filter((answer, index) => 
      answer.toLowerCase() === lesson.quiz[index].correctAnswer.toLowerCase()
    ).length + (userAnswer.toLowerCase().trim() === question.correctAnswer.toLowerCase() ? 1 : 0);
    
    const score = Math.round((correctAnswers / lesson.quiz.length) * 100);

    return (
      <div className="p-8 text-center space-y-6">
        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto">
          <CheckCircle className="w-10 h-10 text-green-500" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">クイズ完了！</h2>
          <p className="text-slate-600">
            {lesson.quiz.length}問中{correctAnswers}問正解
          </p>
          <p className="text-3xl font-bold text-green-600 mt-4">{score}点</p>
        </div>
        <div className="animate-pulse">
          <p className="text-slate-500">リズム学習に進んでいます...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-6">
      {/* Quiz Header */}
      <div className="text-center">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">文法小テスト</h2>
        <p className="text-slate-600">動画で学んだ内容を確認しましょう</p>
      </div>

      {/* Progress */}
      <div className="flex items-center justify-between">
        <span className="text-sm text-slate-500">
          問題 {currentQuestion + 1} / {lesson.quiz.length}
        </span>
        <div className="w-32 bg-slate-200 rounded-full h-2">
          <div 
            className="bg-blue-500 h-2 rounded-full transition-all"
            style={{ width: `${((currentQuestion + 1) / lesson.quiz.length) * 100}%` }}
          />
        </div>
      </div>

      {/* Question */}
      <div className="bg-slate-50 rounded-xl p-6">
        <h3 className="text-xl font-semibold text-slate-800 mb-2">
          {question.question}
        </h3>
        <p className="text-slate-600 text-sm">{question.questionJapanese}</p>
      </div>

      {/* Answer Input */}
      <div className="space-y-4">
        <div className="relative">
          <input
            type="text"
            value={userAnswer}
            onChange={(e) => setUserAnswer(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && !showResult && handleSubmitAnswer()}
            disabled={showResult}
            placeholder="答えを入力してください"
            className="w-full p-4 text-lg border-2 border-slate-200 rounded-lg focus:border-blue-500 focus:outline-none disabled:bg-slate-100"
          />
          {showResult && (
            <div className={`absolute right-3 top-1/2 transform -translate-y-1/2 ${
              isCorrect ? 'text-green-500' : 'text-red-500'
            }`}>
              {isCorrect ? (
                <CheckCircle className="w-6 h-6" />
              ) : (
                <XCircle className="w-6 h-6" />
              )}
            </div>
          )}
        </div>
      </div>

      {/* Result */}
      {showResult && (
        <div className={`rounded-xl p-4 ${
          isCorrect ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'
        }`}>
          <div className="flex items-start space-x-3">
            {isCorrect ? (
              <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" />
            ) : (
              <XCircle className="w-6 h-6 text-red-500 flex-shrink-0 mt-0.5" />
            )}
            <div>
              <p className={`font-medium mb-1 ${
                isCorrect ? 'text-green-800' : 'text-red-800'
              }`}>
                {isCorrect ? '正解です！' : '不正解です'}
              </p>
              {!isCorrect && (
                <p className="text-red-700 mb-2">
                  正解: <strong>{question.correctAnswer}</strong>
                </p>
              )}
              <p className={`text-sm ${
                isCorrect ? 'text-green-700' : 'text-red-700'
              }`}>
                {question.explanation}
              </p>
              <p className={`text-xs mt-1 ${
                isCorrect ? 'text-green-600' : 'text-red-600'
              }`}>
                {question.explanationJapanese}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex justify-center space-x-4">
        {!showResult ? (
          <button
            onClick={handleSubmitAnswer}
            disabled={userAnswer.trim() === ''}
            className="bg-blue-500 hover:bg-blue-600 disabled:bg-slate-300 text-white px-8 py-3 rounded-lg font-medium transition-colors"
          >
            回答する
          </button>
        ) : (
          <button
            onClick={handleNextQuestion}
            className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 rounded-lg font-medium transition-colors flex items-center space-x-2"
          >
            <span>{isLastQuestion ? 'クイズ完了' : '次の問題'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Instructions */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
        <h4 className="font-medium text-blue-800 mb-2">回答のヒント</h4>
        <ul className="text-sm text-blue-700 space-y-1">
          <li>• 空欄に入る適切な単語を入力してください</li>
          <li>• 大文字・小文字は区別されません</li>
          <li>• Enterキーでも回答できます</li>
        </ul>
      </div>
    </div>
  );
};
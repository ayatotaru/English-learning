import React from 'react';
import { Trophy, Star, CheckCircle, ArrowRight } from 'lucide-react';
import { Lesson } from '../../data/lessons';

interface LessonCompleteProps {
  lesson: Lesson;
  scores: Record<string, number>;
  onComplete: () => void;
}

export const LessonComplete: React.FC<LessonCompleteProps> = ({ lesson, scores, onComplete }) => {
  const steps = [
    { key: 'video', label: '動画学習', icon: '📺' },
    { key: 'quiz', label: 'クイズ', icon: '📝' },
    { key: 'rhythm', label: 'リズム', icon: '🎵' },
    { key: 'vocabulary', label: '単語', icon: '📚' },
    { key: 'pronunciation', label: '発音', icon: '🎤' },
  ];

  const totalScore = Object.values(scores).reduce((sum, score) => sum + score, 0);
  const averageScore = Math.round(totalScore / Object.keys(scores).length);
  const pointsEarned = averageScore * 10;

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 80) return 'text-blue-600';
    if (score >= 70) return 'text-orange-600';
    return 'text-red-600';
  };

  const getScoreBadge = (score: number) => {
    if (score >= 90) return '🏆';
    if (score >= 80) return '🥈';
    if (score >= 70) return '🥉';
    return '📝';
  };

  return (
    <div className="p-8 space-y-8">
      {/* Celebration Header */}
      <div className="text-center space-y-4">
        <div className="w-24 h-24 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto">
          <Trophy className="w-12 h-12 text-white" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-slate-800 mb-2">
            レッスン完了！🎉
          </h1>
          <p className="text-xl text-slate-600">
            {lesson.titleJapanese}
          </p>
          <p className="text-slate-500">{lesson.title}</p>
        </div>
      </div>

      {/* Overall Score */}
      <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl p-6 text-white text-center">
        <div className="space-y-2">
          <p className="text-blue-100">総合スコア</p>
          <p className="text-5xl font-bold">{averageScore}</p>
          <p className="text-blue-100">獲得ポイント: {pointsEarned}pt</p>
        </div>
      </div>

      {/* Step Scores */}
      <div className="bg-white rounded-xl p-6 shadow-sm border">
        <h3 className="text-lg font-semibold text-slate-800 mb-4">各ステップの成績</h3>
        <div className="space-y-3">
          {steps.map((step) => {
            const score = scores[step.key] || 0;
            return (
              <div key={step.key} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <span className="text-2xl">{step.icon}</span>
                  <span className="font-medium text-slate-800">{step.label}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-2xl">{getScoreBadge(score)}</span>
                  <span className={`text-xl font-bold ${getScoreColor(score)}`}>
                    {score}点
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Achievement Badges */}
      <div className="bg-yellow-50 rounded-xl p-6 border border-yellow-200">
        <h3 className="text-lg font-semibold text-yellow-800 mb-4">獲得バッジ</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="w-16 h-16 bg-yellow-200 rounded-full flex items-center justify-center mx-auto mb-2">
              <CheckCircle className="w-8 h-8 text-yellow-600" />
            </div>
            <p className="text-sm font-medium text-yellow-800">レッスン完了</p>
          </div>
          
          {averageScore >= 80 && (
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-200 rounded-full flex items-center justify-center mx-auto mb-2">
                <Star className="w-8 h-8 text-blue-600" />
              </div>
              <p className="text-sm font-medium text-blue-800">優秀な成績</p>
            </div>
          )}
          
          {averageScore >= 90 && (
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-200 rounded-full flex items-center justify-center mx-auto mb-2">
                <Trophy className="w-8 h-8 text-purple-600" />
              </div>
              <p className="text-sm font-medium text-purple-800">パーフェクト</p>
            </div>
          )}
          
          {Object.values(scores).every(score => score >= 70) && (
            <div className="text-center">
              <div className="w-16 h-16 bg-green-200 rounded-full flex items-center justify-center mx-auto mb-2">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <p className="text-sm font-medium text-green-800">全ステップクリア</p>
            </div>
          )}
        </div>
      </div>

      {/* Learning Summary */}
      <div className="bg-slate-50 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-slate-800 mb-4">学習内容まとめ</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-medium text-slate-700 mb-2">学習した文法</h4>
            <ul className="text-sm text-slate-600 space-y-1">
              {lesson.grammarPoints.map((point, index) => (
                <li key={index} className="flex items-start space-x-2">
                  <span className="text-blue-500">•</span>
                  <span>{point}</span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="font-medium text-slate-700 mb-2">習得した単語</h4>
            <div className="flex flex-wrap gap-2">
              {lesson.vocabulary.map((vocab, index) => (
                <span
                  key={index}
                  className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full"
                >
                  {vocab.english}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Next Steps */}
      <div className="bg-gradient-to-r from-green-400 to-blue-500 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xl font-semibold mb-2">次のステップ</h3>
            <p className="text-green-100">
              素晴らしい成果です！次のレッスンに進みましょう。
            </p>
          </div>
          <ArrowRight className="w-12 h-12 text-green-200" />
        </div>
      </div>

      {/* Complete Button */}
      <div className="text-center">
        <button
          onClick={onComplete}
          className="bg-blue-500 hover:bg-blue-600 text-white px-12 py-4 rounded-lg font-semibold text-lg transition-colors"
        >
          ダッシュボードに戻る
        </button>
      </div>
    </div>
  );
};
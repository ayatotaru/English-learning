import React, { useState } from 'react';
import { Mic, Volume2, CheckCircle, Play } from 'lucide-react';
import { Lesson } from '../../data/lessons';

interface PronunciationSectionProps {
  lesson: Lesson;
  onComplete: (score: number) => void;
}

export const PronunciationSection: React.FC<PronunciationSectionProps> = ({ lesson, onComplete }) => {
  const [currentWord, setCurrentWord] = useState(0);
  const [isRecording, setIsRecording] = useState(false);
  const [recordedWords, setRecordedWords] = useState<Set<number>>(new Set());
  const [practiceScores, setPracticeScores] = useState<number[]>([]);

  const pronunciationExercises = lesson.pronunciationExercises;
  const currentExercise = pronunciationExercises[currentWord];
  const isLastWord = currentWord === pronunciationExercises.length - 1;

  const handleStartRecording = () => {
    setIsRecording(true);
    
    // Simulate recording for 3 seconds
    setTimeout(() => {
      setIsRecording(false);
      setRecordedWords(prev => new Set([...prev, currentWord]));
      
      // Simulate pronunciation score (random for demo)
      const score = Math.floor(Math.random() * 30) + 70; // 70-100
      setPracticeScores(prev => [...prev, score]);
      
      // Auto advance after recording
      setTimeout(() => {
        if (isLastWord) {
          const averageScore = practiceScores.reduce((sum, s) => sum + s, score) / (practiceScores.length + 1);
          onComplete(Math.round(averageScore));
        } else {
          setCurrentWord(prev => prev + 1);
        }
      }, 2000);
    }, 3000);
  };

  const playExample = () => {
    // Simulate audio playback
    console.log(`Playing pronunciation for: ${currentExercise.word}`);
  };

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">発音練習</h2>
        <p className="text-slate-600">正しい発音を身につけましょう</p>
      </div>

      {/* Progress */}
      <div className="flex items-center justify-between">
        <span className="text-sm text-slate-500">
          単語 {currentWord + 1} / {pronunciationExercises.length}
        </span>
        <div className="w-32 bg-slate-200 rounded-full h-2">
          <div 
            className="bg-purple-500 h-2 rounded-full transition-all"
            style={{ width: `${((currentWord + 1) / pronunciationExercises.length) * 100}%` }}
          />
        </div>
      </div>

      {/* Word Display */}
      <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-8 text-center">
        <div className="space-y-4">
          <h3 className="text-5xl font-bold text-slate-800">{currentExercise.word}</h3>
          <p className="text-xl text-slate-600">{currentExercise.phonetic}</p>
          <button
            onClick={playExample}
            className="p-4 bg-purple-500 hover:bg-purple-600 text-white rounded-full transition-colors"
          >
            <Volume2 className="w-6 h-6" />
          </button>
          <p className="text-sm text-slate-500">お手本を聞く</p>
        </div>
      </div>

      {/* Pronunciation Tips */}
      <div className="bg-blue-50 rounded-xl p-6">
        <h4 className="font-semibold text-blue-800 mb-3">発音のコツ</h4>
        <ul className="space-y-2">
          {currentExercise.tips.map((tip, index) => (
            <li key={index} className="flex items-start space-x-2">
              <div className="w-5 h-5 bg-blue-200 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-blue-700 text-xs font-bold">{index + 1}</span>
              </div>
              <span className="text-blue-800 text-sm">{tip}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Recording Section */}
      <div className="bg-white border border-slate-200 rounded-xl p-6">
        <div className="text-center space-y-4">
          <h4 className="text-lg font-semibold text-slate-800">あなたの発音を録音</h4>
          
          {recordedWords.has(currentWord) ? (
            <div className="space-y-3">
              <CheckCircle className="w-12 h-12 text-green-500 mx-auto" />
              <p className="text-green-600 font-medium">録音完了！</p>
              <div className="bg-green-50 rounded-lg p-4">
                <p className="text-green-800">
                  発音スコア: <span className="font-bold text-2xl">{practiceScores[practiceScores.length - 1]}点</span>
                </p>
                <p className="text-green-600 text-sm mt-1">
                  {practiceScores[practiceScores.length - 1] >= 90 ? '素晴らしい発音です！' :
                   practiceScores[practiceScores.length - 1] >= 80 ? 'とても良い発音です！' :
                   'もう少し練習してみましょう！'}
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <button
                onClick={handleStartRecording}
                disabled={isRecording}
                className={`w-20 h-20 rounded-full flex items-center justify-center transition-all ${
                  isRecording
                    ? 'bg-red-500 animate-pulse'
                    : 'bg-red-500 hover:bg-red-600'
                } text-white`}
              >
                <Mic className="w-8 h-8" />
              </button>
              
              <p className="text-slate-600">
                {isRecording ? '録音中... (3秒間)' : 'マイクボタンを押して録音開始'}
              </p>
              
              {isRecording && (
                <div className="flex justify-center space-x-1">
                  {[...Array(3)].map((_, i) => (
                    <div
                      key={i}
                      className="w-2 h-8 bg-red-400 rounded animate-pulse"
                      style={{ animationDelay: `${i * 0.2}s` }}
                    />
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Practice History */}
      {practiceScores.length > 0 && (
        <div className="bg-slate-50 rounded-xl p-6">
          <h4 className="font-semibold text-slate-800 mb-3">練習履歴</h4>
          <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
            {practiceScores.map((score, index) => (
              <div key={index} className="text-center">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-bold ${
                  score >= 90 ? 'bg-green-500' :
                  score >= 80 ? 'bg-blue-500' :
                  'bg-orange-500'
                }`}>
                  {score}
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  {pronunciationExercises[index]?.word}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Instructions */}
      <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
        <h4 className="font-medium text-yellow-800 mb-2">発音練習のポイント</h4>
        <ul className="text-sm text-yellow-700 space-y-1">
          <li>• まずお手本の音声をよく聞きましょう</li>
          <li>• 発音のコツを参考に口の形を意識しましょう</li>
          <li>• はっきりと大きな声で発音しましょう</li>
          <li>• 録音ボタンを押してから3秒間で発音してください</li>
        </ul>
      </div>
    </div>
  );
};
import React, { useState } from 'react';
import { Volume2, CheckCircle, XCircle, RotateCcw } from 'lucide-react';
import { Lesson, VocabularyItem } from '../../data/lessons';

interface VocabularySectionProps {
  lesson: Lesson;
  onComplete: (score: number) => void;
}

export const VocabularySection: React.FC<VocabularySectionProps> = ({ lesson, onComplete }) => {
  const [currentWord, setCurrentWord] = useState(0);
  const [studyPhase, setStudyPhase] = useState<'learn' | 'test'>('learn');
  const [userAnswers, setUserAnswers] = useState<string[]>([]);
  const [currentAnswer, setCurrentAnswer] = useState('');
  const [showResult, setShowResult] = useState(false);
  const [learnedWords, setLearnedWords] = useState<Set<number>>(new Set());

  const vocabulary = lesson.vocabulary;
  const currentVocab = vocabulary[currentWord];
  const isLastWord = currentWord === vocabulary.length - 1;

  // 各単語に対応する穴埋め問題を生成
  const generateQuizSentence = (vocab: VocabularyItem) => {
    // 例文から単語を抜いて穴埋め問題を作成
    const sentence = vocab.example;
    const word = vocab.english;
    
    // 大文字小文字を考慮して単語を探して置換
    const regex = new RegExp(`\\b${word}\\b`, 'gi');
    const quizSentence = sentence.replace(regex, '_____');
    
    return {
      sentence: quizSentence,
      japanese: vocab.exampleJapanese,
      answer: word.toLowerCase()
    };
  };

  const handleLearnComplete = () => {
    setLearnedWords(prev => new Set([...prev, currentWord]));
    
    if (isLastWord) {
      setStudyPhase('test');
      setCurrentWord(0);
    } else {
      setCurrentWord(prev => prev + 1);
    }
  };

  const handleAnswerSubmit = () => {
    const newAnswers = [...userAnswers, currentAnswer];
    setUserAnswers(newAnswers);
    setShowResult(true);

    setTimeout(() => {
      if (isLastWord) {
        // Calculate score
        const correctAnswers = newAnswers.filter((answer, index) => 
          answer.toLowerCase().trim() === vocabulary[index].english.toLowerCase()
        ).length;
        const score = Math.round((correctAnswers / vocabulary.length) * 100);
        onComplete(score);
      } else {
        setCurrentWord(prev => prev + 1);
        setCurrentAnswer('');
        setShowResult(false);
      }
    }, 2000);
  };

  const isCorrectAnswer = () => {
    return currentAnswer.toLowerCase().trim() === currentVocab.english.toLowerCase();
  };

  const resetSection = () => {
    setCurrentWord(0);
    setStudyPhase('learn');
    setUserAnswers([]);
    setCurrentAnswer('');
    setShowResult(false);
    setLearnedWords(new Set());
  };

  if (studyPhase === 'learn') {
    return (
      <div className="p-8 space-y-6">
        {/* Header */}
        <div className="text-center">
          <h2 className="text-2xl font-bold text-slate-800 mb-2">単語学習</h2>
          <p className="text-slate-600">6つの新しい単語を覚えましょう</p>
        </div>

        {/* Progress */}
        <div className="flex items-center justify-between">
          <span className="text-sm text-slate-500">
            単語 {currentWord + 1} / {vocabulary.length}
          </span>
          <div className="w-32 bg-slate-200 rounded-full h-2">
            <div 
              className="bg-blue-500 h-2 rounded-full transition-all"
              style={{ width: `${((currentWord + 1) / vocabulary.length) * 100}%` }}
            />
          </div>
        </div>

        {/* Word Card */}
        <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-8 text-center">
          <div className="space-y-4">
            <h3 className="text-4xl font-bold text-slate-800">{currentVocab.english}</h3>
            <p className="text-lg text-slate-600">{currentVocab.pronunciation}</p>
            <button className="p-3 bg-blue-500 hover:bg-blue-600 text-white rounded-full transition-colors">
              <Volume2 className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Translation */}
        <div className="bg-white border border-slate-200 rounded-xl p-6">
          <div className="text-center space-y-3">
            <h4 className="text-2xl font-semibold text-slate-800">{currentVocab.japanese}</h4>
            <p className="text-slate-600">{currentVocab.romaji}</p>
          </div>
        </div>

        {/* Example */}
        <div className="bg-slate-50 rounded-xl p-6">
          <h4 className="font-semibold text-slate-800 mb-3">例文</h4>
          <div className="space-y-2">
            <p className="text-slate-800">{currentVocab.example}</p>
            <p className="text-slate-600 text-sm">{currentVocab.exampleJapanese}</p>
          </div>
        </div>

        {/* Action Button */}
        <div className="text-center">
          <button
            onClick={handleLearnComplete}
            className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 rounded-lg font-medium transition-colors"
          >
            {isLastWord ? '穴埋め問題に進む' : '次の単語'}
          </button>
        </div>
      </div>
    );
  }

  // Test Phase - 英文穴埋め問題
  const quizData = generateQuizSentence(currentVocab);

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">穴埋め問題</h2>
        <p className="text-slate-600">学習した単語を使って英文を完成させましょう</p>
      </div>

      {/* Progress */}
      <div className="flex items-center justify-between">
        <span className="text-sm text-slate-500">
          問題 {currentWord + 1} / {vocabulary.length}
        </span>
        <div className="w-32 bg-slate-200 rounded-full h-2">
          <div 
            className="bg-green-500 h-2 rounded-full transition-all"
            style={{ width: `${((currentWord + 1) / vocabulary.length) * 100}%` }}
          />
        </div>
      </div>

      {/* Question */}
      <div className="bg-slate-50 rounded-xl p-6">
        <h3 className="text-xl font-semibold text-slate-800 mb-4">
          空欄に適切な英単語を入力してください
        </h3>
        <div className="space-y-4">
          {/* English sentence with blank */}
          <div className="bg-white rounded-lg p-4 border-2 border-blue-200">
            <p className="text-xl font-medium text-slate-800 text-center">
              {quizData.sentence}
            </p>
          </div>
          {/* Japanese translation */}
          <div className="text-center">
            <p className="text-lg text-slate-600">
              日本語訳: {quizData.japanese}
            </p>
          </div>
        </div>
      </div>

      {/* Answer Input */}
      <div className="space-y-4">
        <div className="relative">
          <input
            type="text"
            value={currentAnswer}
            onChange={(e) => setCurrentAnswer(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && !showResult && currentAnswer.trim() && handleAnswerSubmit()}
            disabled={showResult}
            placeholder="英単語を入力してください"
            className="w-full p-4 text-xl text-center border-2 border-slate-200 rounded-lg focus:border-blue-500 focus:outline-none disabled:bg-slate-100"
          />
          
          {showResult && (
            <div className={`absolute right-3 top-1/2 transform -translate-y-1/2 ${
              isCorrectAnswer() ? 'text-green-500' : 'text-red-500'
            }`}>
              {isCorrectAnswer() ? (
                <CheckCircle className="w-6 h-6" />
              ) : (
                <XCircle className="w-6 h-6" />
              )}
            </div>
          )}
        </div>
        
        {!showResult && (
          <div className="text-center">
            <button
              onClick={handleAnswerSubmit}
              disabled={!currentAnswer.trim()}
              className="bg-green-500 hover:bg-green-600 disabled:bg-slate-300 text-white px-8 py-3 rounded-lg font-medium transition-colors"
            >
              回答する
            </button>
          </div>
        )}
      </div>

      {/* Result */}
      {showResult && (
        <div className={`rounded-xl p-6 text-center ${
          isCorrectAnswer() 
            ? 'bg-green-50 border border-green-200' 
            : 'bg-red-50 border border-red-200'
        }`}>
          <div className="space-y-3">
            {isCorrectAnswer() ? (
              <CheckCircle className="w-12 h-12 text-green-500 mx-auto" />
            ) : (
              <XCircle className="w-12 h-12 text-red-500 mx-auto" />
            )}
            
            <h4 className={`text-xl font-semibold ${
              isCorrectAnswer() ? 'text-green-800' : 'text-red-800'
            }`}>
              {isCorrectAnswer() ? '正解！' : '不正解'}
            </h4>
            
            {!isCorrectAnswer() && (
              <div className="space-y-2">
                <p className="text-red-700">正解: <strong>{currentVocab.english}</strong></p>
                <p className="text-red-600 text-sm">{currentVocab.pronunciation}</p>
                <p className="text-red-600 text-sm">意味: {currentVocab.japanese}</p>
              </div>
            )}
            
            {/* Complete sentence display */}
            <div className="bg-white rounded-lg p-4 mt-4">
              <p className="text-slate-800 font-medium">{currentVocab.example}</p>
              <p className="text-slate-600 text-sm mt-1">{currentVocab.exampleJapanese}</p>
            </div>
          </div>
        </div>
      )}

      {/* Hint section */}
      {!showResult && (
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
          <h4 className="font-medium text-blue-800 mb-2">ヒント</h4>
          <div className="text-sm text-blue-700 space-y-1">
            <p>• 発音: {currentVocab.pronunciation}</p>
            <p>• 意味: {currentVocab.japanese}</p>
            <p>• 大文字・小文字は区別されません</p>
          </div>
        </div>
      )}

      {/* Reset Button */}
      <div className="text-center">
        <button
          onClick={resetSection}
          className="text-slate-600 hover:text-slate-800 flex items-center space-x-2 mx-auto"
        >
          <RotateCcw className="w-4 h-4" />
          <span>最初からやり直す</span>
        </button>
      </div>
    </div>
  );
};
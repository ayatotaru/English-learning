import React from 'react';
import { TrendingUp, Calendar, Clock, Target, Star, BookOpen, MessageSquare, GraduationCap } from 'lucide-react';
import { StudyProgress } from '../App';

interface ProgressSectionProps {
  progress: StudyProgress;
}

export const ProgressSection: React.FC<ProgressSectionProps> = ({ progress }) => {
  const getProgressPercentage = (current: number, total: number) => {
    return Math.min((current / total) * 100, 100);
  };

  const studyData = [
    {
      subject: '単語',
      icon: BookOpen,
      current: progress.vocabularyStudied,
      total: 500,
      color: 'from-blue-500 to-blue-600',
      bgColor: 'bg-blue-50',
      textColor: 'text-blue-700'
    },
    {
      subject: 'フレーズ',
      icon: MessageSquare,
      current: progress.phrasesLearned,
      total: 200,
      color: 'from-green-500 to-emerald-600',
      bgColor: 'bg-green-50',
      textColor: 'text-green-700'
    },
    {
      subject: '文法',
      icon: GraduationCap,
      current: progress.grammarLessons,
      total: 100,
      color: 'from-purple-500 to-purple-600',
      bgColor: 'bg-purple-50',
      textColor: 'text-purple-700'
    }
  ];

  const achievements = [
    {
      title: '初心者卒業',
      description: '基本的な単語を100個学習',
      icon: Star,
      unlocked: progress.vocabularyStudied >= 100,
      color: 'text-yellow-500'
    },
    {
      title: '継続は力なり',
      description: '7日連続で学習',
      icon: Calendar,
      unlocked: progress.studyStreak >= 7,
      color: 'text-orange-500'
    },
    {
      title: '会話マスター',
      description: '日常フレーズを50個習得',
      icon: MessageSquare,
      unlocked: progress.phrasesLearned >= 50,
      color: 'text-green-500'
    },
    {
      title: '文法博士',
      description: '文法レッスンを10個完了',
      icon: GraduationCap,
      unlocked: progress.grammarLessons >= 10,
      color: 'text-purple-500'
    }
  ];

  const weeklyData = [
    { day: '月', study: 45 },
    { day: '火', study: 30 },
    { day: '水', study: 60 },
    { day: '木', study: 25 },
    { day: '金', study: 55 },
    { day: '土', study: 70 },
    { day: '日', study: 40 }
  ];

  const maxStudyTime = Math.max(...weeklyData.map(d => d.study));

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold text-slate-800 mb-2">学習進捗</h2>
        <p className="text-slate-600">あなたの英語学習の成果を確認しましょう</p>
      </div>

      {/* Overall Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-sm">学習ストリーク</p>
              <p className="text-3xl font-bold">{progress.studyStreak}</p>
              <p className="text-blue-100 text-sm">日間継続</p>
            </div>
            <Target className="w-10 h-10 text-blue-200" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-green-500 to-teal-600 rounded-xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-100 text-sm">総学習時間</p>
              <p className="text-3xl font-bold">{Math.floor(progress.totalStudyTime / 60)}</p>
              <p className="text-green-100 text-sm">時間</p>
            </div>
            <Clock className="w-10 h-10 text-green-200" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-orange-500 to-red-600 rounded-xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-orange-100 text-sm">今週の学習</p>
              <p className="text-3xl font-bold">6</p>
              <p className="text-orange-100 text-sm">日間</p>
            </div>
            <Calendar className="w-10 h-10 text-orange-200" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-purple-500 to-pink-600 rounded-xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-100 text-sm">総合レベル</p>
              <p className="text-3xl font-bold">B1</p>
              <p className="text-purple-100 text-sm">中級</p>
            </div>
            <TrendingUp className="w-10 h-10 text-purple-200" />
          </div>
        </div>
      </div>

      {/* Subject Progress */}
      <div className="bg-white rounded-xl p-6 shadow-sm border">
        <h3 className="text-xl font-semibold text-slate-800 mb-6">分野別進捗</h3>
        <div className="space-y-6">
          {studyData.map((subject, index) => {
            const Icon = subject.icon;
            const percentage = getProgressPercentage(subject.current, subject.total);
            
            return (
              <div key={index} className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 ${subject.bgColor} rounded-lg flex items-center justify-center`}>
                      <Icon className={`w-5 h-5 ${subject.textColor}`} />
                    </div>
                    <div>
                      <p className="font-medium text-slate-800">{subject.subject}</p>
                      <p className="text-sm text-slate-500">{subject.current} / {subject.total} 完了</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-slate-800">{percentage.toFixed(0)}%</p>
                  </div>
                </div>
                <div className="w-full bg-slate-200 rounded-full h-3">
                  <div
                    className={`h-3 rounded-full bg-gradient-to-r ${subject.color} transition-all duration-500`}
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Weekly Chart */}
      <div className="bg-white rounded-xl p-6 shadow-sm border">
        <h3 className="text-xl font-semibold text-slate-800 mb-6">週間学習時間</h3>
        <div className="flex items-end justify-between space-x-2 h-48">
          {weeklyData.map((day, index) => (
            <div key={index} className="flex flex-col items-center flex-1">
              <div className="w-full bg-slate-100 rounded-t-lg relative" style={{ height: '160px' }}>
                <div
                  className="bg-gradient-to-t from-blue-500 to-blue-400 rounded-t-lg absolute bottom-0 w-full transition-all duration-500"
                  style={{ height: `${(day.study / maxStudyTime) * 100}%` }}
                />
                <div className="absolute top-2 left-1/2 transform -translate-x-1/2 text-xs font-medium text-slate-600">
                  {day.study}分
                </div>
              </div>
              <p className="text-sm font-medium text-slate-600 mt-2">{day.day}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Achievements */}
      <div className="bg-white rounded-xl p-6 shadow-sm border">
        <h3 className="text-xl font-semibold text-slate-800 mb-6">達成バッジ</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {achievements.map((achievement, index) => {
            const Icon = achievement.icon;
            return (
              <div
                key={index}
                className={`p-4 rounded-lg border-2 text-center transition-all ${
                  achievement.unlocked
                    ? 'border-yellow-200 bg-yellow-50'
                    : 'border-slate-200 bg-slate-50 opacity-60'
                }`}
              >
                <Icon className={`w-8 h-8 mx-auto mb-2 ${achievement.unlocked ? achievement.color : 'text-slate-400'}`} />
                <h4 className={`font-semibold mb-1 ${achievement.unlocked ? 'text-slate-800' : 'text-slate-500'}`}>
                  {achievement.title}
                </h4>
                <p className={`text-xs ${achievement.unlocked ? 'text-slate-600' : 'text-slate-400'}`}>
                  {achievement.description}
                </p>
                {achievement.unlocked && (
                  <div className="mt-2">
                    <span className="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full">
                      達成済み
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Motivational Section */}
      <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl p-6 text-white text-center">
        <h3 className="text-2xl font-bold mb-2">素晴らしい進歩です！</h3>
        <p className="text-indigo-100 mb-4">
          継続的な学習により、着実に英語力が向上しています。
        </p>
        <div className="inline-flex items-center space-x-2 bg-white/20 px-4 py-2 rounded-full">
          <Star className="w-5 h-5 text-yellow-300" />
          <span className="text-sm font-medium">次の目標まで頑張りましょう！</span>
        </div>
      </div>
    </div>
  );
};
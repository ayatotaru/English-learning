import React, { useState } from 'react';
import { Play, BookOpen, Clock, Star } from 'lucide-react';
import { StudyProgress } from '../App';

interface Phrase {
  id: number;
  english: string;
  japanese: string;
  romaji: string;
  situation: string;
  formality: 'casual' | 'polite' | 'formal';
  category: string;
  audioTip: string;
}

interface PhrasesSectionProps {
  progress: StudyProgress;
  updateProgress: (progress: Partial<StudyProgress>) => void;
}

export const PhrasesSection: React.FC<PhrasesSectionProps> = ({ progress, updateProgress }) => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [studiedPhrases, setStudiedPhrases] = useState<Set<number>>(new Set());

  const phrases: Phrase[] = [
    {
      id: 1,
      english: "Nice to meet you!",
      japanese: "はじめまして！",
      romaji: "Hajimemashite!",
      situation: "初対面の人に挨拶する時",
      formality: "polite",
      category: "greetings",
      audioTip: "「ナイス トゥ ミート ユー」"
    },
    {
      id: 2,
      english: "How's it going?",
      japanese: "調子はどう？",
      romaji: "Choushi wa dou?",
      situation: "友達に近況を聞く時",
      formality: "casual",
      category: "greetings",
      audioTip: "「ハウズ イット ゴーイング」"
    },
    {
      id: 3,
      english: "Could you help me?",
      japanese: "手伝ってもらえませんか？",
      romaji: "Tetsudatte moraemasen ka?",
      situation: "丁寧に助けを求める時",
      formality: "polite",
      category: "requests",
      audioTip: "「クッド ユー ヘルプ ミー」"
    },
    {
      id: 4,
      english: "I'm looking forward to it!",
      japanese: "楽しみにしています！",
      romaji: "Tanoshimi ni shite imasu!",
      situation: "何かを心待ちにしている時",
      formality: "polite",
      category: "emotions",
      audioTip: "「アイム ルッキング フォワード トゥ イット」"
    },
    {
      id: 5,
      english: "That makes sense.",
      japanese: "なるほど、そうですね。",
      romaji: "Naruhodo, sou desu ne.",
      situation: "相手の話に納得した時",
      formality: "polite",
      category: "conversation",
      audioTip: "「ザット メイクス センス」"
    },
    {
      id: 6,
      english: "I'd like to order, please.",
      japanese: "注文をお願いします。",
      romaji: "Chuumon wo onegai shimasu.",
      situation: "レストランで注文する時",
      formality: "polite",
      category: "dining",
      audioTip: "「アイド ライク トゥ オーダー プリーズ」"
    }
  ];

  const categories = [
    { id: 'all', label: 'すべて', color: 'bg-slate-100 text-slate-700' },
    { id: 'greetings', label: '挨拶', color: 'bg-blue-100 text-blue-700' },
    { id: 'requests', label: '依頼', color: 'bg-green-100 text-green-700' },
    { id: 'emotions', label: '感情表現', color: 'bg-pink-100 text-pink-700' },
    { id: 'conversation', label: '会話', color: 'bg-purple-100 text-purple-700' },
    { id: 'dining', label: '食事', color: 'bg-orange-100 text-orange-700' }
  ];

  const filteredPhrases = selectedCategory === 'all' 
    ? phrases 
    : phrases.filter(phrase => phrase.category === selectedCategory);

  const handlePhraseStudied = (phraseId: number) => {
    if (!studiedPhrases.has(phraseId)) {
      setStudiedPhrases(prev => new Set([...prev, phraseId]));
      updateProgress({ 
        phrasesLearned: progress.phrasesLearned + 1,
        totalStudyTime: progress.totalStudyTime + 1
      });
    }
  };

  const getFormalityColor = (formality: string) => {
    switch (formality) {
      case 'casual': return 'bg-green-100 text-green-700';
      case 'polite': return 'bg-blue-100 text-blue-700';
      case 'formal': return 'bg-purple-100 text-purple-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getFormalityLabel = (formality: string) => {
    switch (formality) {
      case 'casual': return 'カジュアル';
      case 'polite': return '丁寧';
      case 'formal': return 'フォーマル';
      default: return '';
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold text-slate-800 mb-2">フレーズ練習</h2>
        <p className="text-slate-600">日常会話で使える英語フレーズを学習</p>
      </div>

      {/* Category Filter */}
      <div className="flex flex-wrap gap-2 justify-center">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => setSelectedCategory(category.id)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
              selectedCategory === category.id 
                ? category.color + ' shadow-sm' 
                : 'bg-white text-slate-600 hover:bg-slate-50'
            }`}
          >
            {category.label}
          </button>
        ))}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-lg p-4 shadow-sm border text-center">
          <div className="text-2xl font-bold text-green-600">{studiedPhrases.size}</div>
          <div className="text-sm text-slate-600">今日学習したフレーズ</div>
        </div>
        <div className="bg-white rounded-lg p-4 shadow-sm border text-center">
          <div className="text-2xl font-bold text-blue-600">{progress.phrasesLearned}</div>
          <div className="text-sm text-slate-600">総学習フレーズ数</div>
        </div>
        <div className="bg-white rounded-lg p-4 shadow-sm border text-center">
          <div className="text-2xl font-bold text-purple-600">{filteredPhrases.length}</div>
          <div className="text-sm text-slate-600">このカテゴリーのフレーズ</div>
        </div>
      </div>

      {/* Phrases Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredPhrases.map((phrase) => (
          <div
            key={phrase.id}
            className={`bg-white rounded-xl p-6 shadow-sm border-2 transition-all duration-200 hover:shadow-md ${
              studiedPhrases.has(phrase.id) 
                ? 'border-green-200 bg-green-50' 
                : 'border-slate-200 hover:border-blue-200'
            }`}
          >
            <div className="space-y-4">
              {/* Header */}
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-2">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${getFormalityColor(phrase.formality)}`}>
                    {getFormalityLabel(phrase.formality)}
                  </span>
                  {studiedPhrases.has(phrase.id) && (
                    <Star className="w-4 h-4 text-yellow-500 fill-current" />
                  )}
                </div>
                <button className="p-2 text-blue-500 hover:bg-blue-50 rounded-lg transition-colors">
                  <Play className="w-4 h-4" />
                </button>
              </div>

              {/* English Phrase */}
              <div>
                <h3 className="text-xl font-bold text-slate-800 mb-2">{phrase.english}</h3>
                <p className="text-sm text-blue-600 font-medium">{phrase.audioTip}</p>
              </div>

              {/* Japanese Translation */}
              <div className="bg-slate-50 rounded-lg p-4">
                <p className="text-lg font-semibold text-slate-800">{phrase.japanese}</p>
                <p className="text-sm text-slate-600 mt-1">{phrase.romaji}</p>
              </div>

              {/* Usage Context */}
              <div className="flex items-start space-x-2">
                <Clock className="w-4 h-4 text-slate-400 mt-0.5 flex-shrink-0" />
                <p className="text-sm text-slate-600">{phrase.situation}</p>
              </div>

              {/* Study Button */}
              <button
                onClick={() => handlePhraseStudied(phrase.id)}
                disabled={studiedPhrases.has(phrase.id)}
                className={`w-full py-2 px-4 rounded-lg font-medium transition-all ${
                  studiedPhrases.has(phrase.id)
                    ? 'bg-green-100 text-green-700 cursor-not-allowed'
                    : 'bg-blue-500 text-white hover:bg-blue-600'
                }`}
              >
                {studiedPhrases.has(phrase.id) ? '学習済み' : '学習完了'}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Practice Section */}
      <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xl font-semibold mb-2">実践練習</h3>
            <p className="text-blue-100">学習したフレーズを実際の会話で使ってみましょう</p>
          </div>
          <BookOpen className="w-12 h-12 text-blue-200" />
        </div>
        <button className="mt-4 bg-white text-blue-600 px-6 py-2 rounded-lg font-medium hover:bg-blue-50 transition-colors">
          練習を始める
        </button>
      </div>
    </div>
  );
};
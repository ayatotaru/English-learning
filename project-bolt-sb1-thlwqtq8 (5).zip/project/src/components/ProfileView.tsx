import React, { useState } from 'react';
import { User, Settings, Mail, Calendar, Trophy, Edit2, Save, X } from 'lucide-react';
import { User as UserType } from '../App';

interface ProfileViewProps {
  user: UserType | null;
  onUpdateUser: (user: UserType) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ user, onUpdateUser }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedName, setEditedName] = useState(user?.name || '');

  const handleSave = () => {
    if (user && editedName.trim()) {
      onUpdateUser({
        ...user,
        name: editedName.trim()
      });
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditedName(user?.name || '');
    setIsEditing(false);
  };

  if (!user) {
    return (
      <div className="max-w-2xl mx-auto text-center py-12">
        <p className="text-slate-600">ユーザー情報を読み込み中...</p>
      </div>
    );
  }

  const profileStats = [
    {
      label: '現在のレベル',
      value: user.level,
      icon: Trophy,
      color: 'text-purple-600',
      bgColor: 'bg-purple-100'
    },
    {
      label: '総ポイント',
      value: user.totalPoints,
      icon: Trophy,
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-100'
    },
    {
      label: '学習ストリーク',
      value: `${user.streak}日`,
      icon: Calendar,
      color: 'text-orange-600',
      bgColor: 'bg-orange-100'
    }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-slate-800 mb-2">プロフィール</h1>
        <p className="text-slate-600">あなたの学習情報を管理</p>
      </div>

      {/* Profile Card */}
      <div className="bg-white rounded-xl p-8 shadow-sm border">
        <div className="flex items-center space-x-6">
          {/* Avatar */}
          <div className="w-24 h-24 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
            <span className="text-white text-3xl font-bold">
              {user.name.charAt(0)}
            </span>
          </div>

          {/* User Info */}
          <div className="flex-1">
            <div className="flex items-center space-x-3 mb-2">
              {isEditing ? (
                <div className="flex items-center space-x-2">
                  <input
                    type="text"
                    value={editedName}
                    onChange={(e) => setEditedName(e.target.value)}
                    className="text-2xl font-bold text-slate-800 border-b-2 border-blue-500 focus:outline-none bg-transparent"
                  />
                  <button
                    onClick={handleSave}
                    className="p-1 text-green-600 hover:bg-green-100 rounded"
                  >
                    <Save className="w-4 h-4" />
                  </button>
                  <button
                    onClick={handleCancel}
                    className="p-1 text-red-600 hover:bg-red-100 rounded"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <h2 className="text-2xl font-bold text-slate-800">{user.name}</h2>
                  <button
                    onClick={() => setIsEditing(true)}
                    className="p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
            
            <div className="flex items-center space-x-4 text-slate-600">
              <div className="flex items-center space-x-1">
                <Mail className="w-4 h-4" />
                <span className="text-sm">{user.email}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Calendar className="w-4 h-4" />
                <span className="text-sm">
                  登録日: {new Date(user.createdAt).toLocaleDateString('ja-JP')}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {profileStats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-xl p-6 shadow-sm border text-center">
              <div className={`w-16 h-16 ${stat.bgColor} rounded-full flex items-center justify-center mx-auto mb-4`}>
                <Icon className={`w-8 h-8 ${stat.color}`} />
              </div>
              <p className="text-3xl font-bold text-slate-800 mb-2">{stat.value}</p>
              <p className="text-sm text-slate-500">{stat.label}</p>
            </div>
          );
        })}
      </div>

      {/* Learning Preferences */}
      <div className="bg-white rounded-xl p-6 shadow-sm border">
        <h3 className="text-xl font-semibold text-slate-800 mb-6 flex items-center">
          <Settings className="w-5 h-5 mr-2" />
          学習設定
        </h3>
        
        <div className="space-y-6">
          {/* Daily Goal */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              1日の学習目標時間
            </label>
            <select className="w-full p-3 border border-slate-200 rounded-lg focus:border-blue-500 focus:outline-none">
              <option value="15">15分</option>
              <option value="30" selected>30分</option>
              <option value="45">45分</option>
              <option value="60">60分</option>
            </select>
          </div>

          {/* Notification Settings */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-3">
              通知設定
            </label>
            <div className="space-y-3">
              <label className="flex items-center">
                <input type="checkbox" className="rounded border-slate-300 text-blue-600 focus:ring-blue-500" defaultChecked />
                <span className="ml-2 text-sm text-slate-600">学習リマインダー</span>
              </label>
              <label className="flex items-center">
                <input type="checkbox" className="rounded border-slate-300 text-blue-600 focus:ring-blue-500" defaultChecked />
                <span className="ml-2 text-sm text-slate-600">達成バッジ通知</span>
              </label>
              <label className="flex items-center">
                <input type="checkbox" className="rounded border-slate-300 text-blue-600 focus:ring-blue-500" />
                <span className="ml-2 text-sm text-slate-600">週間レポート</span>
              </label>
            </div>
          </div>

          {/* Difficulty Level */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              学習レベル
            </label>
            <select className="w-full p-3 border border-slate-200 rounded-lg focus:border-blue-500 focus:outline-none">
              <option value="beginner" selected>初級</option>
              <option value="intermediate">中級</option>
              <option value="advanced">上級</option>
            </select>
          </div>
        </div>

        <div className="mt-6 pt-6 border-t border-slate-200">
          <button className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded-lg font-medium transition-colors">
            設定を保存
          </button>
        </div>
      </div>

      {/* Account Actions */}
      <div className="bg-white rounded-xl p-6 shadow-sm border">
        <h3 className="text-xl font-semibold text-slate-800 mb-6">アカウント管理</h3>
        
        <div className="space-y-4">
          <button className="w-full text-left p-4 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium text-slate-800">学習データをエクスポート</h4>
                <p className="text-sm text-slate-600">あなたの学習履歴をダウンロード</p>
              </div>
              <span className="text-slate-400">→</span>
            </div>
          </button>

          <button className="w-full text-left p-4 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium text-slate-800">学習データをリセット</h4>
                <p className="text-sm text-slate-600">進捗を初期状態に戻す</p>
              </div>
              <span className="text-slate-400">→</span>
            </div>
          </button>

          <button className="w-full text-left p-4 border border-red-200 rounded-lg hover:bg-red-50 transition-colors text-red-600">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium">アカウントを削除</h4>
                <p className="text-sm text-red-500">すべてのデータが削除されます</p>
              </div>
              <span className="text-red-400">→</span>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};
import React from 'react';
import { TrendingUp, Calendar, Clock, Target, Star, Trophy, CheckCircle } from 'lucide-react';
import { User, UserProgress } from '../App';
import { lessons } from '../data/lessons';

interface ProgressViewProps {
  user: User | null;
  userProgress: UserProgress | null;
}

export const ProgressView: React.FC<ProgressViewProps> = ({ user, userProgress }) => {
  const getCompletedLessons = () => {
    return userProgress?.lessonProgress?.filter(p => p.completed).length || 0;
  };

  const getAverageScore = () => {
    const completedLessons = userProgress?.lessonProgress?.filter(p => p.completed) || [];
    if (completedLessons.length === 0) return 0;
    
    const totalScore = completedLessons.reduce((sum, lesson) => sum + lesson.score, 0);
    return Math.round(totalScore / completedLessons.length);
  };

  const getWeeklyStudyData = () => {
    // Mock weekly data - in real app, this would come from database
    return [
      { day: '月', minutes: 45, lessons: 1 },
      { day: '火', minutes: 30, lessons: 0 },
      { day: '水', minutes: 60, lessons: 2 },
      { day: '木', minutes: 25, lessons: 1 },
      { day: '金', minutes: 55, lessons: 1 },
      { day: '土', minutes: 70, lessons: 2 },
      { day: '日', minutes: 40, lessons: 1 }
    ];
  };

  const weeklyData = getWeeklyStudyData();
  const maxMinutes = Math.max(...weeklyData.map(d => d.minutes));

  const stats = [
    {
      label: '完了レッスン',
      value: getCompletedLessons(),
      total: lessons.length,
      icon: CheckCircle,
      color: 'text-green-600',
      bgColor: 'bg-green-100'
    },
    {
      label: '平均スコア',
      value: `${getAverageScore()}点`,
      icon: Star,
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-100'
    },
    {
      label: '学習ストリーク',
      value: `${userProgress?.streak || 0}日`,
      icon: Target,
      color: 'text-orange-600',
      bgColor: 'bg-orange-100'
    },
    {
      label: '総ポイント',
      value: user?.totalPoints || 0,
      icon: Trophy,
      color: 'text-purple-600',
      bgColor: 'bg-purple-100'
    }
  ];

  const achievements = [
    {
      title: '初心者卒業',
      description: '最初のレッスンを完了',
      icon: '🎓',
      unlocked: getCompletedLessons() >= 1,
      progress: Math.min(getCompletedLessons(), 1),
      total: 1
    },
    {
      title: '継続は力なり',
      description: '7日連続で学習',
      icon: '🔥',
      unlocked: (userProgress?.streak || 0) >= 7,
      progress: Math.min(userProgress?.streak || 0, 7),
      total: 7
    },
    {
      title: '優等生',
      description: '平均スコア80点以上',
      icon: '⭐',
      unlocked: getAverageScore() >= 80,
      progress: Math.min(getAverageScore(), 80),
      total: 80
    },
    {
      title: 'レッスンマスター',
      description: '全レッスンを完了',
      icon: '👑',
      unlocked: getCompletedLessons() >= lessons.length,
      progress: getCompletedLessons(),
      total: lessons.length
    }
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-slate-800 mb-2">学習進捗</h1>
        <p className="text-slate-600">あなたの英語学習の成果を確認しましょう</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-xl p-6 shadow-sm border">
              <div className="flex items-center justify-between mb-3">
                <div className={`w-12 h-12 ${stat.bgColor} rounded-lg flex items-center justify-center`}>
                  <Icon className={`w-6 h-6 ${stat.color}`} />
                </div>
              </div>
              <p className="text-2xl font-bold text-slate-800 mb-1">
                {'total' in stat ? `${stat.value}/${stat.total}` : stat.value}
              </p>
              <p className="text-sm text-slate-500">{stat.label}</p>
            </div>
          );
        })}
      </div>

      {/* Overall Progress */}
      <div className="bg-gradient-to-r from-blue-500 to-indigo-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-xl font-semibold mb-2">全体の進捗</h3>
            <p className="text-blue-100">
              {getCompletedLessons()} / {lessons.length} レッスン完了
            </p>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold">
              {Math.round((getCompletedLessons() / lessons.length) * 100)}%
            </div>
            <div className="text-sm text-blue-100">完了率</div>
          </div>
        </div>
        <div className="w-full bg-white/20 rounded-full h-3">
          <div 
            className="bg-white rounded-full h-3 transition-all duration-500"
            style={{ width: `${(getCompletedLessons() / lessons.length) * 100}%` }}
          />
        </div>
      </div>

      {/* Weekly Study Chart */}
      <div className="bg-white rounded-xl p-6 shadow-sm border">
        <h3 className="text-xl font-semibold text-slate-800 mb-6">週間学習時間</h3>
        <div className="flex items-end justify-between space-x-2 h-48">
          {weeklyData.map((day, index) => (
            <div key={index} className="flex flex-col items-center flex-1">
              <div className="w-full bg-slate-100 rounded-t-lg relative" style={{ height: '160px' }}>
                <div
                  className="bg-gradient-to-t from-blue-500 to-blue-400 rounded-t-lg absolute bottom-0 w-full transition-all duration-500"
                  style={{ height: `${(day.minutes / maxMinutes) * 100}%` }}
                />
                <div className="absolute top-2 left-1/2 transform -translate-x-1/2 text-xs font-medium text-slate-600">
                  {day.minutes}分
                </div>
                {day.lessons > 0 && (
                  <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 text-xs bg-white rounded-full px-2 py-1 text-blue-600 font-medium">
                    {day.lessons}レッスン
                  </div>
                )}
              </div>
              <p className="text-sm font-medium text-slate-600 mt-2">{day.day}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Lesson Progress */}
      <div className="bg-white rounded-xl p-6 shadow-sm border">
        <h3 className="text-xl font-semibold text-slate-800 mb-6">レッスン別成績</h3>
        <div className="space-y-4">
          {lessons.map((lesson) => {
            const progress = userProgress?.lessonProgress?.find(p => p.lessonId === lesson.id);
            const isCompleted = progress?.completed || false;
            const score = progress?.score || 0;
            
            return (
              <div
                key={lesson.id}
                className={`p-4 rounded-lg border-2 transition-all ${
                  isCompleted
                    ? 'border-green-200 bg-green-50'
                    : 'border-slate-200 bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3">
                      <span className="bg-blue-100 text-blue-700 text-xs font-medium px-2 py-1 rounded-full">
                        レッスン {lesson.id}
                      </span>
                      {isCompleted && (
                        <CheckCircle className="w-5 h-5 text-green-500" />
                      )}
                    </div>
                    <h4 className="font-semibold text-slate-800 mt-2">{lesson.titleJapanese}</h4>
                    <p className="text-sm text-slate-600">{lesson.title}</p>
                  </div>
                  
                  <div className="text-right">
                    {isCompleted ? (
                      <div>
                        <div className={`text-2xl font-bold ${
                          score >= 90 ? 'text-green-600' :
                          score >= 80 ? 'text-blue-600' :
                          score >= 70 ? 'text-orange-600' :
                          'text-red-600'
                        }`}>
                          {score}点
                        </div>
                        <div className="text-xs text-slate-500">
                          {progress?.completedAt && new Date(progress.completedAt).toLocaleDateString('ja-JP')}
                        </div>
                      </div>
                    ) : (
                      <div className="text-slate-400">
                        <div className="text-sm">未完了</div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Achievements */}
      <div className="bg-white rounded-xl p-6 shadow-sm border">
        <h3 className="text-xl font-semibold text-slate-800 mb-6">達成バッジ</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {achievements.map((achievement, index) => (
            <div
              key={index}
              className={`p-4 rounded-lg border-2 text-center transition-all ${
                achievement.unlocked
                  ? 'border-yellow-200 bg-yellow-50'
                  : 'border-slate-200 bg-slate-50'
              }`}
            >
              <div className="text-4xl mb-2">{achievement.icon}</div>
              <h4 className={`font-semibold mb-1 ${
                achievement.unlocked ? 'text-slate-800' : 'text-slate-500'
              }`}>
                {achievement.title}
              </h4>
              <p className={`text-xs mb-3 ${
                achievement.unlocked ? 'text-slate-600' : 'text-slate-400'
              }`}>
                {achievement.description}
              </p>
              
              <div className="space-y-2">
                <div className="w-full bg-slate-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full transition-all ${
                      achievement.unlocked ? 'bg-yellow-400' : 'bg-slate-400'
                    }`}
                    style={{ width: `${(achievement.progress / achievement.total) * 100}%` }}
                  />
                </div>
                <p className="text-xs text-slate-500">
                  {achievement.progress} / {achievement.total}
                </p>
              </div>
              
              {achievement.unlocked && (
                <div className="mt-2">
                  <span className="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full">
                    達成済み
                  </span>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Motivational Section */}
      <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl p-6 text-white text-center">
        <h3 className="text-2xl font-bold mb-2">素晴らしい進歩です！</h3>
        <p className="text-indigo-100 mb-4">
          継続的な学習により、着実に英語力が向上しています。
        </p>
        <div className="inline-flex items-center space-x-2 bg-white/20 px-4 py-2 rounded-full">
          <Star className="w-5 h-5 text-yellow-300" />
          <span className="text-sm font-medium">この調子で頑張りましょう！</span>
        </div>
      </div>
    </div>
  );
};
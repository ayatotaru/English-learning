import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import type { AuthUser, UserProfile, AuthContextType, SignUpData, SignInData } from '../types/auth';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: React.ReactNode;
}

// エラーメッセージを日本語に変換する関数
const getJapaneseErrorMessage = (error: any): string => {
  const message = error?.message || '';
  const code = error?.code || '';

  // レート制限エラー
  if (code === 'over_email_send_rate_limit' || message.includes('For security purposes')) {
    return 'セキュリティのため、8秒後に再度お試しください。';
  }

  // 認証情報エラー
  if (code === 'invalid_credentials' || message.includes('Invalid login credentials')) {
    return 'メールアドレスまたはパスワードが正しくありません。入力内容をご確認ください。';
  }

  // メール未確認エラー
  if (code === 'email_not_confirmed' || message.includes('Email not confirmed')) {
    return 'メールアドレスが確認されていません。受信したメールの確認リンクをクリックしてください。';
  }

  // パスワード強度エラー
  if (message.includes('Password should be at least')) {
    return 'パスワードは6文字以上で入力してください。';
  }

  // メールアドレス形式エラー
  if (message.includes('Invalid email')) {
    return '有効なメールアドレスを入力してください。';
  }

  // ユーザー既存エラー
  if (code === 'user_already_exists' || message.includes('already registered')) {
    return 'このメールアドレスは既に登録されています。ログインをお試しください。';
  }

  // ネットワークエラー
  if (message.includes('Failed to fetch') || message.includes('Network')) {
    return 'ネットワークエラーが発生しました。インターネット接続をご確認ください。';
  }

  // タイムアウトエラー
  if (message.includes('timeout') || message.includes('タイムアウト')) {
    return 'サーバーへの接続がタイムアウトしました。しばらく時間をおいて再度お試しください。';
  }

  // その他のエラー
  return message || '予期しないエラーが発生しました。しばらく時間をおいて再度お試しください。';
};

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [initialized, setInitialized] = useState(false);

  // エラーをクリア
  const clearError = () => setError(null);

  // プロファイルを取得
  const fetchProfile = async (userId: string): Promise<UserProfile | null> => {
    try {
      console.log('プロファイル取得開始:', userId);
      
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) {
        console.error('Profile fetch error:', error);
        
        // プロファイルが存在しない場合は作成を試行
        if (error.code === 'PGRST116') {
          console.log('プロファイルが存在しないため、作成を試行します');
          return null;
        }
        
        throw error;
      }

      console.log('プロファイル取得成功:', data);
      return data;
    } catch (err) {
      console.error('Profile fetch error:', err);
      return null;
    }
  };

  // 認証状態の初期化（修正版）
  const initializeAuth = async () => {
    try {
      console.log('認証初期化開始...');
      setLoading(true);
      setError(null);

      // 環境変数チェック
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
      
      if (!supabaseUrl || !supabaseKey) {
        throw new Error('Supabase環境変数が設定されていません。設定を確認してください。');
      }

      console.log('環境変数確認完了');
      console.log('Supabase URL:', supabaseUrl ? '設定済み' : '未設定');
      console.log('Supabase Key:', supabaseKey ? '設定済み' : '未設定');

      // セッション取得（タイムアウトを削除し、シンプルに実行）
      console.log('セッション取得中...');
      
      // 最大3回リトライ
      let sessionData = null;
      let sessionError = null;
      
      for (let attempt = 1; attempt <= 3; attempt++) {
        try {
          console.log(`セッション取得試行 ${attempt}/3`);
          const result = await supabase.auth.getSession();
          sessionData = result.data;
          sessionError = result.error;
          
          if (!sessionError) {
            console.log('セッション取得成功');
            break;
          } else {
            console.warn(`セッション取得エラー (試行 ${attempt}):`, sessionError);
            if (attempt < 3) {
              // 1秒待ってリトライ
              await new Promise(resolve => setTimeout(resolve, 1000));
            }
          }
        } catch (err) {
          console.error(`セッション取得例外 (試行 ${attempt}):`, err);
          sessionError = err;
          if (attempt < 3) {
            await new Promise(resolve => setTimeout(resolve, 1000));
          }
        }
      }

      if (sessionError) {
        console.error('セッション取得に失敗しました:', sessionError);
        // セッション取得に失敗しても、未認証状態として続行
        setUser(null);
        setProfile(null);
      } else if (sessionData?.session?.user) {
        console.log('既存セッション発見:', sessionData.session.user.email);
        setUser(sessionData.session.user as AuthUser);
        
        // プロファイル取得（エラーが発生しても続行）
        try {
          const userProfile = await fetchProfile(sessionData.session.user.id);
          setProfile(userProfile);
        } catch (profileError) {
          console.warn('プロファイル取得に失敗しましたが、認証は継続します:', profileError);
        }
      } else {
        console.log('セッションなし - 未認証状態');
        setUser(null);
        setProfile(null);
      }

      setInitialized(true);
      console.log('認証初期化完了');
      
    } catch (err: any) {
      console.error('認証初期化エラー:', err);
      setError(getJapaneseErrorMessage(err));
      setInitialized(true);
      
      // エラーが発生しても未認証状態として続行
      setUser(null);
      setProfile(null);
    } finally {
      setLoading(false);
    }
  };

  // 認証状態の監視
  useEffect(() => {
    let mounted = true;
    let authSubscription: any = null;

    // 初期化
    initializeAuth();

    // 認証状態変更の監視
    try {
      authSubscription = supabase.auth.onAuthStateChange(
        async (event, session) => {
          if (!mounted) return;

          console.log('Auth state changed:', event, session?.user?.email);
          
          try {
            if (session?.user) {
              setUser(session.user as AuthUser);
              
              // プロファイル取得（エラーが発生しても続行）
              try {
                const userProfile = await fetchProfile(session.user.id);
                if (mounted) {
                  setProfile(userProfile);
                }
              } catch (profileError) {
                console.warn('プロファイル取得エラー（認証状態変更時）:', profileError);
              }
            } else {
              setUser(null);
              setProfile(null);
            }
          } catch (err) {
            console.error('Auth state change error:', err);
          }
        }
      );
    } catch (err) {
      console.error('Auth subscription error:', err);
    }

    return () => {
      mounted = false;
      if (authSubscription?.data?.subscription) {
        try {
          authSubscription.data.subscription.unsubscribe();
        } catch (err) {
          console.warn('Auth subscription cleanup error:', err);
        }
      }
    };
  }, []);

  // サインアップ
  const signUp = async ({ email, password, fullName }: SignUpData) => {
    try {
      console.log('サインアップ開始:', email);
      setLoading(true);
      setError(null);

      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName || email.split('@')[0],
          },
        },
      });

      console.log('サインアップ結果:', { data: !!data, error });

      if (error) {
        throw error;
      }

      if (data.user && !data.session) {
        // メール確認が必要な場合
        setError('確認メールを送信しました。メールをチェックしてアカウントを有効化してください。迷惑メールフォルダもご確認ください。');
      }
    } catch (err: any) {
      console.error('Sign up error:', err);
      const errorMessage = getJapaneseErrorMessage(err);
      setError(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // サインイン
  const signIn = async ({ email, password }: SignInData) => {
    try {
      console.log('サインイン開始:', email);
      setLoading(true);
      setError(null);

      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      console.log('サインイン結果:', { data: !!data, error });

      if (error) {
        throw error;
      }

      console.log('サインイン成功');
      // ユーザーとプロファイルは onAuthStateChange で設定される
    } catch (err: any) {
      console.error('Sign in error:', err);
      const errorMessage = getJapaneseErrorMessage(err);
      setError(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Googleサインイン
  const signInWithGoogle = async () => {
    try {
      console.log('Googleサインイン開始');
      setLoading(true);
      setError(null);

      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: `${window.location.origin}/auth/callback`,
        },
      });

      if (error) {
        throw error;
      }
    } catch (err: any) {
      console.error('Google sign in error:', err);
      const errorMessage = getJapaneseErrorMessage(err);
      setError(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // サインアウト
  const signOut = async () => {
    try {
      console.log('サインアウト開始');
      setLoading(true);
      setError(null);

      const { error } = await supabase.auth.signOut();

      if (error) {
        throw error;
      }

      console.log('サインアウト成功');
      // ユーザーとプロファイルは onAuthStateChange でクリアされる
    } catch (err: any) {
      console.error('Sign out error:', err);
      const errorMessage = getJapaneseErrorMessage(err);
      setError(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // パスワードリセット
  const resetPassword = async (email: string) => {
    try {
      console.log('パスワードリセット開始:', email);
      setLoading(true);
      setError(null);

      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/auth/reset-password`,
      });

      if (error) {
        throw error;
      }

      setError('パスワードリセットメールを送信しました。メールをチェックしてください。迷惑メールフォルダもご確認ください。');
    } catch (err: any) {
      console.error('Password reset error:', err);
      const errorMessage = getJapaneseErrorMessage(err);
      setError(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // プロファイル更新
  const updateProfile = async (updates: Partial<UserProfile>) => {
    try {
      if (!user) {
        throw new Error('ユーザーがログインしていません');
      }

      setLoading(true);
      setError(null);

      const { data, error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', user.id)
        .select()
        .single();

      if (error) {
        throw error;
      }

      setProfile(data);
    } catch (err: any) {
      console.error('Profile update error:', err);
      const errorMessage = getJapaneseErrorMessage(err);
      setError(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const value: AuthContextType = {
    user,
    profile,
    loading: loading && !initialized,
    error,
    signUp,
    signIn,
    signInWithGoogle,
    signOut,
    resetPassword,
    updateProfile,
    clearError,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
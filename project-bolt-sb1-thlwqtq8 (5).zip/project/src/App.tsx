import React, { useState } from 'react';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { LessonView } from './components/LessonView';
import { ProgressView } from './components/ProgressView';
import { ProfileView } from './components/ProfileView';
import { ProtectedRoute } from './components/auth/ProtectedRoute';
import { AuthProvider } from './contexts/AuthContext';
import { useUserProgress } from './hooks/useUserProgress';
import { useAuth } from './contexts/AuthContext';

export type ViewType = 'dashboard' | 'lesson' | 'progress' | 'profile';

export interface User {
  id: string;
  email: string;
  name: string;
  level: number;
  totalPoints: number;
  streak: number;
  createdAt: string;
}

export interface LessonProgress {
  lessonId: number;
  completed: boolean;
  videoWatched: boolean;
  quizCompleted: boolean;
  rhythmCompleted: boolean;
  vocabularyCompleted: boolean;
  pronunciationCompleted: boolean;
  score: number;
  completedAt?: string;
}

export interface UserProgress {
  userId: string;
  currentLesson: number;
  totalLessonsCompleted: number;
  totalPoints: number;
  streak: number;
  lastStudyDate: string;
  lessonProgress: LessonProgress[];
}

// メインアプリコンポーネント（認証済みユーザー用）
const AuthenticatedApp: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewType>('dashboard');
  const [currentLessonId, setCurrentLessonId] = useState<number | null>(null);

  const { user: authUser, profile, loading: authLoading } = useAuth();
  const { userProgress, updateUserProgress, loading: progressLoading, error: progressError } = useUserProgress();

  const loading = authLoading || progressLoading;

  // 認証ユーザーをアプリのUser型に変換
  const user: User | null = authUser && profile ? {
    id: authUser.id,
    email: authUser.email,
    name: profile.full_name || authUser.email,
    level: 1,
    totalPoints: userProgress?.totalPoints || 0,
    streak: userProgress?.streak || 0,
    createdAt: authUser.created_at
  } : null;

  const startLesson = (lessonId: number) => {
    setCurrentLessonId(lessonId);
    setCurrentView('lesson');
  };

  const completeLesson = async (lessonId: number, score: number) => {
    if (!userProgress) return;

    try {
      const updatedLessonProgress = [...userProgress.lessonProgress];
      const existingIndex = updatedLessonProgress.findIndex(p => p.lessonId === lessonId);

      const completedLesson: LessonProgress = {
        lessonId,
        completed: true,
        videoWatched: true,
        quizCompleted: true,
        rhythmCompleted: true,
        vocabularyCompleted: true,
        pronunciationCompleted: true,
        score,
        completedAt: new Date().toISOString()
      };

      if (existingIndex >= 0) {
        updatedLessonProgress[existingIndex] = completedLesson;
      } else {
        updatedLessonProgress.push(completedLesson);
      }

      const newTotalCompleted = updatedLessonProgress.filter(p => p.completed).length;
      const pointsEarned = Math.max(0, score * 10);

      await updateUserProgress({
        lessonProgress: updatedLessonProgress,
        totalLessonsCompleted: newTotalCompleted,
        totalPoints: userProgress.totalPoints + pointsEarned,
        currentLesson: Math.max(userProgress.currentLesson, lessonId + 1),
        lastStudyDate: new Date().toISOString()
      });

      setCurrentView('dashboard');
    } catch (error) {
      console.error('Error completing lesson:', error);
    }
  };

  const renderCurrentView = () => {
    switch (currentView) {
      case 'dashboard':
        return (
          <Dashboard
            user={user}
            userProgress={userProgress}
            onStartLesson={startLesson}
          />
        );
      case 'lesson':
        return currentLessonId ? (
          <LessonView
            lessonId={currentLessonId}
            userProgress={userProgress}
            onCompleteLesson={completeLesson}
            onBack={() => setCurrentView('dashboard')}
          />
        ) : null;
      case 'progress':
        return (
          <ProgressView
            user={user}
            userProgress={userProgress}
          />
        );
      case 'profile':
        return (
          <ProfileView
            user={user}
            onUpdateUser={() => {}}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <Header
        currentView={currentView}
        onViewChange={setCurrentView}
        user={user}
      />
      <main className="container mx-auto px-4 py-6 max-w-6xl">
        {loading ? (
          <div className="flex items-center justify-center min-h-96">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
              <p className="text-slate-600">学習データを読み込み中...</p>
              {progressError && (
                <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-red-700 text-sm">{progressError}</p>
                  <button
                    onClick={() => window.location.reload()}
                    className="mt-2 text-red-600 hover:text-red-800 text-sm underline"
                  >
                    ページを再読み込み
                  </button>
                </div>
              )}
            </div>
          </div>
        ) : (
          renderCurrentView()
        )}
      </main>
    </div>
  );
};

// ルートアプリコンポーネント
function App() {
  return (
    <AuthProvider>
      <ProtectedRoute>
        <AuthenticatedApp />
      </ProtectedRoute>
    </AuthProvider>
  );
}

export default App;
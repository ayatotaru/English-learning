export interface Lesson {
  id: number;
  title: string;
  titleJapanese: string;
  description: string;
  videoUrl: string;
  level: number;
  orderIndex: number;
  grammarPoints: string[];
  vocabulary: VocabularyItem[];
  quiz: QuizQuestion[];
  rhythmContent: RhythmContent;
  pronunciationExercises: PronunciationExercise[];
}

export interface VocabularyItem {
  english: string;
  japanese: string;
  romaji: string;
  pronunciation: string;
  example: string;
  exampleJapanese: string;
}

export interface QuizQuestion {
  id: number;
  type: 'fill-blank';
  question: string;
  questionJapanese: string;
  correctAnswer: string;
  explanation: string;
  explanationJapanese: string;
}

export interface RhythmContent {
  title: string;
  bpm: number;
  phrases: RhythmPhrase[];
}

export interface RhythmPhrase {
  english: string;
  japanese: string;
  timing: number[];
  emphasis: number[];
}

export interface PronunciationExercise {
  word: string;
  phonetic: string;
  audioUrl?: string;
  tips: string[];
}

// Helper function to generate basic lesson content for lessons 4-30
const generateBasicLessonContent = (id: number, title: string, titleJapanese: string, description: string, grammarPoints: string[], level: number): Lesson => {
  const basicVocabulary: VocabularyItem[] = [
    {
      english: "Example",
      japanese: "例",
      romaji: "rei",
      pronunciation: "/ɪɡˈzæmpəl/",
      example: "This is an example.",
      exampleJapanese: "これは例です。"
    },
    {
      english: "Study",
      japanese: "勉強する",
      romaji: "benkyou suru",
      pronunciation: "/ˈstʌdi/",
      example: "I study English.",
      exampleJapanese: "私は英語を勉強します。"
    },
    {
      english: "Learn",
      japanese: "学ぶ",
      romaji: "manabu",
      pronunciation: "/lɜːrn/",
      example: "We learn grammar.",
      exampleJapanese: "私たちは文法を学びます。"
    },
    {
      english: "Practice",
      japanese: "練習する",
      romaji: "renshuu suru",
      pronunciation: "/ˈpræktɪs/",
      example: "Practice makes perfect.",
      exampleJapanese: "練習が完璧を作ります。"
    },
    {
      english: "Understand",
      japanese: "理解する",
      romaji: "rikai suru",
      pronunciation: "/ˌʌndərˈstænd/",
      example: "Do you understand?",
      exampleJapanese: "理解していますか？"
    },
    {
      english: "Remember",
      japanese: "覚える",
      romaji: "oboeru",
      pronunciation: "/rɪˈmembər/",
      example: "Please remember this.",
      exampleJapanese: "これを覚えてください。"
    }
  ];

  // Generate 10 fill-blank questions based on the lesson topic
  const generateQuizQuestions = (lessonId: number, title: string): QuizQuestion[] => {
    const questions: QuizQuestion[] = [];
    
    // Basic template questions that can be adapted for different grammar topics
    const templates = [
      { english: "I _____ a student.", japanese: "私は学生です。", answer: "am" },
      { english: "She _____ very kind.", japanese: "彼女はとても親切です。", answer: "is" },
      { english: "We _____ happy today.", japanese: "私たちは今日幸せです。", answer: "are" },
      { english: "He _____ my friend.", japanese: "彼は私の友達です。", answer: "is" },
      { english: "You _____ very smart.", japanese: "あなたはとても賢いです。", answer: "are" },
      { english: "It _____ a beautiful day.", japanese: "美しい日です。", answer: "is" },
      { english: "They _____ at home.", japanese: "彼らは家にいます。", answer: "are" },
      { english: "I _____ from Japan.", japanese: "私は日本出身です。", answer: "am" },
      { english: "This _____ my book.", japanese: "これは私の本です。", answer: "is" },
      { english: "We _____ ready to go.", japanese: "私たちは行く準備ができています。", answer: "are" }
    ];

    templates.forEach((template, index) => {
      questions.push({
        id: index + 1,
        type: 'fill-blank',
        question: template.english,
        questionJapanese: template.japanese,
        correctAnswer: template.answer,
        explanation: `Use "${template.answer}" with this subject.`,
        explanationJapanese: `この主語には"${template.answer}"を使います。`
      });
    });

    return questions;
  };

  const basicRhythm: RhythmContent = {
    title: `${titleJapanese} Rhythm`,
    bpm: 120,
    phrases: [
      {
        english: "Let's practice together",
        japanese: "一緒に練習しましょう",
        timing: [0, 0.5, 1.0, 1.5],
        emphasis: [0, 2]
      },
      {
        english: "This is important",
        japanese: "これは重要です",
        timing: [0, 0.5, 1.0],
        emphasis: [0, 2]
      }
    ]
  };

  const basicPronunciation: PronunciationExercise[] = [
    {
      word: "Example",
      phonetic: "/ɪɡˈzæmpəl/",
      tips: [
        "Stress on the second syllable",
        "Clear 'g' sound in the middle",
        "End with 'pul' sound"
      ]
    },
    {
      word: "Study",
      phonetic: "/ˈstʌdi/",
      tips: [
        "Stress on first syllable",
        "Short 'u' sound like in 'cup'",
        "End with 'dee' sound"
      ]
    },
    {
      word: "Practice",
      phonetic: "/ˈpræktɪs/",
      tips: [
        "Stress on first syllable",
        "Short 'a' sound",
        "Clear 'k' sound in middle"
      ]
    }
  ];

  return {
    id,
    title,
    titleJapanese,
    description,
    videoUrl: `https://example.com/lesson${id}-video`,
    level,
    orderIndex: id,
    grammarPoints,
    vocabulary: basicVocabulary,
    quiz: generateQuizQuestions(id, title),
    rhythmContent: basicRhythm,
    pronunciationExercises: basicPronunciation
  };
};

export const lessons: Lesson[] = [
  // Lesson 1 - Updated to use fill-blank format
  {
    id: 1,
    title: "Basic Greetings and Introductions",
    titleJapanese: "基本的な挨拶と自己紹介",
    description: "Learn essential greetings and how to introduce yourself in English",
    videoUrl: "https://example.com/lesson1-video",
    level: 1,
    orderIndex: 1,
    grammarPoints: [
      "Present tense 'be' verb (am, is, are)",
      "Basic sentence structure: Subject + Verb + Object",
      "Question formation with 'What' and 'How'"
    ],
    vocabulary: [
      {
        english: "Hello",
        japanese: "こんにちは",
        romaji: "konnichiwa",
        pronunciation: "/həˈloʊ/",
        example: "Hello, nice to meet you!",
        exampleJapanese: "こんにちは、はじめまして！"
      },
      {
        english: "Name",
        japanese: "名前",
        romaji: "namae",
        pronunciation: "/neɪm/",
        example: "My name is John.",
        exampleJapanese: "私の名前はジョンです。"
      },
      {
        english: "Nice",
        japanese: "素晴らしい",
        romaji: "subarashii",
        pronunciation: "/naɪs/",
        example: "Nice to meet you!",
        exampleJapanese: "お会いできて嬉しいです！"
      },
      {
        english: "Meet",
        japanese: "会う",
        romaji: "au",
        pronunciation: "/miːt/",
        example: "Let's meet tomorrow.",
        exampleJapanese: "明日会いましょう。"
      },
      {
        english: "Please",
        japanese: "お願いします",
        romaji: "onegaishimasu",
        pronunciation: "/pliːz/",
        example: "Please help me.",
        exampleJapanese: "助けてください。"
      },
      {
        english: "Thank",
        japanese: "感謝する",
        romaji: "kansha suru",
        pronunciation: "/θæŋk/",
        example: "Thank you very much.",
        exampleJapanese: "どうもありがとうございます。"
      }
    ],
    quiz: [
      {
        id: 1,
        type: 'fill-blank',
        question: "Hello, my _____ is Sarah.",
        questionJapanese: "こんにちは、私の_____はサラです。",
        correctAnswer: "name",
        explanation: "We use 'name' to introduce ourselves.",
        explanationJapanese: "自己紹介では'name'を使います。"
      },
      {
        id: 2,
        type: 'fill-blank',
        question: "_____ to meet you!",
        questionJapanese: "_____お会いできて嬉しいです！",
        correctAnswer: "Nice",
        explanation: "We say 'Nice to meet you' when meeting someone for the first time.",
        explanationJapanese: "初めて会う人には'Nice to meet you'と言います。"
      },
      {
        id: 3,
        type: 'fill-blank',
        question: "_____ you very much.",
        questionJapanese: "_____どうもありがとうございます。",
        correctAnswer: "Thank",
        explanation: "We use 'Thank' to express gratitude.",
        explanationJapanese: "感謝を表すには'Thank'を使います。"
      },
      {
        id: 4,
        type: 'fill-blank',
        question: "_____ help me, please.",
        questionJapanese: "_____助けてください。",
        correctAnswer: "Please",
        explanation: "We use 'Please' to make polite requests.",
        explanationJapanese: "丁寧な依頼には'Please'を使います。"
      },
      {
        id: 5,
        type: 'fill-blank',
        question: "Let's _____ tomorrow.",
        questionJapanese: "明日_____ましょう。",
        correctAnswer: "meet",
        explanation: "We use 'meet' to arrange to see someone.",
        explanationJapanese: "誰かと会う約束をするときは'meet'を使います。"
      },
      {
        id: 6,
        type: 'fill-blank',
        question: "_____, how are you?",
        questionJapanese: "_____、元気ですか？",
        correctAnswer: "Hello",
        explanation: "We start conversations with 'Hello'.",
        explanationJapanese: "会話は'Hello'で始めます。"
      },
      {
        id: 7,
        type: 'fill-blank',
        question: "What is your _____?",
        questionJapanese: "あなたの_____は何ですか？",
        correctAnswer: "name",
        explanation: "We ask 'What is your name?' to learn someone's name.",
        explanationJapanese: "相手の名前を聞くときは'What is your name?'と言います。"
      },
      {
        id: 8,
        type: 'fill-blank',
        question: "_____ to meet you too.",
        questionJapanese: "_____こちらこそお会いできて嬉しいです。",
        correctAnswer: "Nice",
        explanation: "We respond with 'Nice to meet you too'.",
        explanationJapanese: "'Nice to meet you too'と返答します。"
      },
      {
        id: 9,
        type: 'fill-blank',
        question: "_____ you later!",
        questionJapanese: "また後で_____！",
        correctAnswer: "See",
        explanation: "We say 'See you later' when saying goodbye.",
        explanationJapanese: "別れの挨拶では'See you later'と言います。"
      },
      {
        id: 10,
        type: 'fill-blank',
        question: "_____ morning!",
        questionJapanese: "_____おはようございます！",
        correctAnswer: "Good",
        explanation: "We say 'Good morning' as a morning greeting.",
        explanationJapanese: "朝の挨拶は'Good morning'と言います。"
      }
    ],
    rhythmContent: {
      title: "Greeting Rhythm",
      bpm: 120,
      phrases: [
        {
          english: "Hello, nice to meet you",
          japanese: "こんにちは、はじめまして",
          timing: [0, 0.5, 1.0, 1.5, 2.0, 2.5],
          emphasis: [0, 2, 5]
        },
        {
          english: "My name is John",
          japanese: "私の名前はジョンです",
          timing: [0, 0.5, 1.0, 1.5],
          emphasis: [0, 3]
        }
      ]
    },
    pronunciationExercises: [
      {
        word: "Hello",
        phonetic: "/həˈloʊ/",
        tips: [
          "Start with a soft 'h' sound",
          "The 'e' is pronounced like 'uh'",
          "End with a long 'o' sound"
        ]
      },
      {
        word: "Name",
        phonetic: "/neɪm/",
        tips: [
          "Start with 'n' sound",
          "The 'a' sounds like 'ay'",
          "End with 'm' sound"
        ]
      },
      {
        word: "Nice",
        phonetic: "/naɪs/",
        tips: [
          "Start with 'n' sound",
          "The 'i' sounds like 'eye'",
          "End with soft 's' sound"
        ]
      },
      {
        word: "Meet",
        phonetic: "/miːt/",
        tips: [
          "Start with 'm' sound",
          "Long 'ee' sound in the middle",
          "End with sharp 't' sound"
        ]
      },
      {
        word: "Please",
        phonetic: "/pliːz/",
        tips: [
          "Start with 'p' sound",
          "Long 'ee' sound",
          "End with 'z' sound"
        ]
      },
      {
        word: "Thank",
        phonetic: "/θæŋk/",
        tips: [
          "Start with 'th' sound (tongue between teeth)",
          "Short 'a' sound like in 'cat'",
          "End with 'nk' sound"
        ]
      }
    ]
  },

  // Lesson 2 - Updated to use fill-blank format
  {
    id: 2,
    title: "Numbers and Time",
    titleJapanese: "数字と時間",
    description: "Learn numbers, telling time, and basic time expressions",
    videoUrl: "https://example.com/lesson2-video",
    level: 1,
    orderIndex: 2,
    grammarPoints: [
      "Cardinal numbers 1-100",
      "Ordinal numbers (1st, 2nd, 3rd)",
      "Time expressions (o'clock, half past, quarter to)"
    ],
    vocabulary: [
      {
        english: "One",
        japanese: "一",
        romaji: "ichi",
        pronunciation: "/wʌn/",
        example: "I have one book.",
        exampleJapanese: "私は本を一冊持っています。"
      },
      {
        english: "Time",
        japanese: "時間",
        romaji: "jikan",
        pronunciation: "/taɪm/",
        example: "What time is it?",
        exampleJapanese: "今何時ですか？"
      },
      {
        english: "Hour",
        japanese: "時",
        romaji: "ji",
        pronunciation: "/aʊər/",
        example: "It's one hour long.",
        exampleJapanese: "それは1時間です。"
      },
      {
        english: "Minute",
        japanese: "分",
        romaji: "fun/pun",
        pronunciation: "/ˈmɪnɪt/",
        example: "Wait a minute.",
        exampleJapanese: "ちょっと待って。"
      },
      {
        english: "Clock",
        japanese: "時計",
        romaji: "tokei",
        pronunciation: "/klɑːk/",
        example: "Look at the clock.",
        exampleJapanese: "時計を見て。"
      },
      {
        english: "Today",
        japanese: "今日",
        romaji: "kyou",
        pronunciation: "/təˈdeɪ/",
        example: "Today is Monday.",
        exampleJapanese: "今日は月曜日です。"
      }
    ],
    quiz: [
      {
        id: 1,
        type: 'fill-blank',
        question: "What _____ is it?",
        questionJapanese: "今何_____ですか？",
        correctAnswer: "time",
        explanation: "We use 'What time is it?' to ask about the current time.",
        explanationJapanese: "現在の時刻を尋ねるときは'What time is it?'を使います。"
      },
      {
        id: 2,
        type: 'fill-blank',
        question: "It's _____ o'clock.",
        questionJapanese: "_____時です。",
        correctAnswer: "three",
        explanation: "We use numbers to tell time.",
        explanationJapanese: "時刻を言うときは数字を使います。"
      },
      {
        id: 3,
        type: 'fill-blank',
        question: "I have _____ books.",
        questionJapanese: "私は_____冊の本を持っています。",
        correctAnswer: "five",
        explanation: "We use numbers to count objects.",
        explanationJapanese: "物を数えるときは数字を使います。"
      },
      {
        id: 4,
        type: 'fill-blank',
        question: "Wait a _____.",
        questionJapanese: "ちょっと_____。",
        correctAnswer: "minute",
        explanation: "We use 'minute' for short periods of time.",
        explanationJapanese: "短い時間には'minute'を使います。"
      },
      {
        id: 5,
        type: 'fill-blank',
        question: "Look at the _____.",
        questionJapanese: "_____を見て。",
        correctAnswer: "clock",
        explanation: "We use 'clock' to refer to timepieces.",
        explanationJapanese: "時計を指すときは'clock'を使います。"
      },
      {
        id: 6,
        type: 'fill-blank',
        question: "_____ is Monday.",
        questionJapanese: "_____は月曜日です。",
        correctAnswer: "Today",
        explanation: "We use 'Today' to refer to the current day.",
        explanationJapanese: "今日を指すときは'Today'を使います。"
      },
      {
        id: 7,
        type: 'fill-blank',
        question: "It's half _____ three.",
        questionJapanese: "3時_____です。",
        correctAnswer: "past",
        explanation: "We use 'half past' for 30 minutes after the hour.",
        explanationJapanese: "30分過ぎには'half past'を使います。"
      },
      {
        id: 8,
        type: 'fill-blank',
        question: "I need _____ hour.",
        questionJapanese: "_____時間必要です。",
        correctAnswer: "one",
        explanation: "We use 'one' before singular nouns.",
        explanationJapanese: "単数名詞の前には'one'を使います。"
      },
      {
        id: 9,
        type: 'fill-blank',
        question: "The class is _____ hours long.",
        questionJapanese: "授業は_____時間です。",
        correctAnswer: "two",
        explanation: "We use numbers to express duration.",
        explanationJapanese: "期間を表すときは数字を使います。"
      },
      {
        id: 10,
        type: 'fill-blank',
        question: "See you at _____ o'clock.",
        questionJapanese: "_____時に会いましょう。",
        correctAnswer: "six",
        explanation: "We use numbers to specify meeting times.",
        explanationJapanese: "待ち合わせ時間を指定するときは数字を使います。"
      }
    ],
    rhythmContent: {
      title: "Time Rhythm",
      bpm: 100,
      phrases: [
        {
          english: "What time is it now?",
          japanese: "今何時ですか？",
          timing: [0, 0.5, 1.0, 1.5, 2.0],
          emphasis: [1, 3]
        },
        {
          english: "It's half past three",
          japanese: "3時半です",
          timing: [0, 0.5, 1.0, 1.5, 2.0],
          emphasis: [1, 4]
        }
      ]
    },
    pronunciationExercises: [
      {
        word: "One",
        phonetic: "/wʌn/",
        tips: [
          "Start with 'w' sound",
          "Short 'u' sound like in 'cup'",
          "End with 'n' sound"
        ]
      },
      {
        word: "Time",
        phonetic: "/taɪm/",
        tips: [
          "Start with 't' sound",
          "Long 'i' sound like 'eye'",
          "End with 'm' sound"
        ]
      },
      {
        word: "Hour",
        phonetic: "/aʊər/",
        tips: [
          "Start with 'ow' sound like in 'how'",
          "End with soft 'r' sound"
        ]
      },
      {
        word: "Minute",
        phonetic: "/ˈmɪnɪt/",
        tips: [
          "Stress on first syllable",
          "Short 'i' sounds",
          "End with soft 't'"
        ]
      },
      {
        word: "Clock",
        phonetic: "/klɑːk/",
        tips: [
          "Start with 'cl' blend",
          "Long 'o' sound",
          "End with hard 'k'"
        ]
      },
      {
        word: "Today",
        phonetic: "/təˈdeɪ/",
        tips: [
          "Stress on second syllable",
          "First syllable sounds like 'tuh'",
          "End with 'day' sound"
        ]
      }
    ]
  },

  // Lesson 3 - Be verbs with your specified quiz questions
  {
    id: 3,
    title: "Be Verbs",
    titleJapanese: "be動詞の基本",
    description: "Learn the basics of 'am', 'is', and 'are' - the foundation of English grammar",
    videoUrl: "https://example.com/lesson3-video",
    level: 1,
    orderIndex: 3,
    grammarPoints: [
      "I am ~ (私は〜です)",
      "You are ~ (あなたは〜です)",
      "He/She/It is ~ (彼/彼女/それは〜です)",
      "We/They are ~ (私たち/彼らは〜です)"
    ],
    vocabulary: [
      {
        english: "Student",
        japanese: "学生",
        romaji: "gakusei",
        pronunciation: "/ˈstuːdənt/",
        example: "I am a student.",
        exampleJapanese: "私は学生です。"
      },
      {
        english: "Brother",
        japanese: "兄・弟",
        romaji: "ani/otouto",
        pronunciation: "/ˈbrʌðər/",
        example: "He is my brother.",
        exampleJapanese: "彼は私の兄です。"
      },
      {
        english: "Happy",
        japanese: "幸せな",
        romaji: "shiawase na",
        pronunciation: "/ˈhæpi/",
        example: "We are happy.",
        exampleJapanese: "私たちは幸せです。"
      },
      {
        english: "Here",
        japanese: "ここに",
        romaji: "koko ni",
        pronunciation: "/hɪər/",
        example: "She is here.",
        exampleJapanese: "彼女はここにいます。"
      },
      {
        english: "Nice",
        japanese: "やさしい",
        romaji: "yasashii",
        pronunciation: "/naɪs/",
        example: "You are very nice.",
        exampleJapanese: "あなたはとてもやさしいです。"
      },
      {
        english: "Dog",
        japanese: "犬",
        romaji: "inu",
        pronunciation: "/dɔːɡ/",
        example: "It is a dog.",
        exampleJapanese: "それは犬です。"
      }
    ],
    quiz: [
      {
        id: 1,
        type: 'fill-blank',
        question: "I _____ a student.",
        questionJapanese: "私は学生です。",
        correctAnswer: "am",
        explanation: "Use 'am' with 'I'.",
        explanationJapanese: "'I'には'am'を使います。"
      },
      {
        id: 2,
        type: 'fill-blank',
        question: "He _____ my brother.",
        questionJapanese: "彼は私の兄です。",
        correctAnswer: "is",
        explanation: "Use 'is' with 'he', 'she', or 'it'.",
        explanationJapanese: "'he', 'she', 'it'には'is'を使います。"
      },
      {
        id: 3,
        type: 'fill-blank',
        question: "We _____ happy.",
        questionJapanese: "私たちはうれしいです。",
        correctAnswer: "are",
        explanation: "Use 'are' with 'we', 'you', or 'they'.",
        explanationJapanese: "'we', 'you', 'they'には'are'を使います。"
      },
      {
        id: 4,
        type: 'fill-blank',
        question: "She _____ here.",
        questionJapanese: "彼女はここにいます。",
        correctAnswer: "is",
        explanation: "Use 'is' with 'he', 'she', or 'it'.",
        explanationJapanese: "'he', 'she', 'it'には'is'を使います。"
      },
      {
        id: 5,
        type: 'fill-blank',
        question: "You _____ very nice.",
        questionJapanese: "あなたはとてもやさしいです。",
        correctAnswer: "are",
        explanation: "Use 'are' with 'we', 'you', or 'they'.",
        explanationJapanese: "'we', 'you', 'they'には'are'を使います。"
      },
      {
        id: 6,
        type: 'fill-blank',
        question: "It _____ a dog.",
        questionJapanese: "それは犬です。",
        correctAnswer: "is",
        explanation: "Use 'is' with 'he', 'she', or 'it'.",
        explanationJapanese: "'he', 'she', 'it'には'is'を使います。"
      },
      {
        id: 7,
        type: 'fill-blank',
        question: "They _____ friends.",
        questionJapanese: "彼らは友達です。",
        correctAnswer: "are",
        explanation: "Use 'are' with 'we', 'you', or 'they'.",
        explanationJapanese: "'we', 'you', 'they'には'are'を使います。"
      },
      {
        id: 8,
        type: 'fill-blank',
        question: "I _____ from Tokyo.",
        questionJapanese: "私は東京出身です。",
        correctAnswer: "am",
        explanation: "Use 'am' with 'I'.",
        explanationJapanese: "'I'には'am'を使います。"
      },
      {
        id: 9,
        type: 'fill-blank',
        question: "This _____ my bag.",
        questionJapanese: "これは私のかばんです。",
        correctAnswer: "is",
        explanation: "Use 'is' with singular subjects like 'this'.",
        explanationJapanese: "'this'のような単数主語には'is'を使います。"
      },
      {
        id: 10,
        type: 'fill-blank',
        question: "He _____ at school.",
        questionJapanese: "彼は学校にいます。",
        correctAnswer: "is",
        explanation: "Use 'is' with 'he', 'she', or 'it'.",
        explanationJapanese: "'he', 'she', 'it'には'is'を使います。"
      }
    ],
    rhythmContent: {
      title: "Be Verbs Rhythm",
      bpm: 120,
      phrases: [
        {
          english: "I am a student",
          japanese: "私は学生です",
          timing: [0, 0.5, 1.0, 1.5],
          emphasis: [0, 2]
        },
        {
          english: "You are very nice",
          japanese: "あなたはとてもやさしいです",
          timing: [0, 0.5, 1.0, 1.5, 2.0],
          emphasis: [0, 2, 4]
        }
      ]
    },
    pronunciationExercises: [
      {
        word: "Am",
        phonetic: "/æm/",
        tips: [
          "Short 'a' sound like in 'cat'",
          "End with 'm' sound",
          "Used only with 'I'"
        ]
      },
      {
        word: "Is",
        phonetic: "/ɪz/",
        tips: [
          "Short 'i' sound",
          "End with 'z' sound",
          "Used with he, she, it"
        ]
      },
      {
        word: "Are",
        phonetic: "/ɑːr/",
        tips: [
          "Long 'a' sound",
          "End with 'r' sound",
          "Used with you, we, they"
        ]
      }
    ]
  },

  // Lessons 4-30 - Generated with basic content but updated quiz format
  generateBasicLessonContent(4, "Articles", "冠詞", "Master the use of 'a', 'an', and 'the' in English sentences", ["Indefinite articles (a, an)", "Definite article (the)", "When to use articles"], 1),
  
  generateBasicLessonContent(5, "Present Simple Tense", "現在形", "Learn how to express habits, facts, and general truths", ["Affirmative sentences", "Negative sentences", "Question formation"], 1),
  
  generateBasicLessonContent(6, "Plural Nouns", "複数形", "Understand how to make nouns plural in English", ["Regular plurals (-s, -es)", "Irregular plurals", "Uncountable nouns"], 1),
  
  generateBasicLessonContent(7, "This, That, These, Those", "指示代名詞", "Learn demonstrative pronouns for pointing out objects", ["Near vs far objects", "Singular vs plural", "Usage in sentences"], 1),
  
  generateBasicLessonContent(8, "Possessive Forms", "所有格", "Express ownership and relationships using possessive forms", ["Possessive adjectives", "Possessive pronouns", "Possessive 's"], 1),
  
  generateBasicLessonContent(9, "Question Words", "疑問詞", "Master who, what, where, when, why, and how", ["Wh-questions", "Question formation", "Answer patterns"], 1),
  
  generateBasicLessonContent(10, "Prepositions of Place", "場所の前置詞", "Learn in, on, at, under, next to, and other location words", ["Basic prepositions", "Common combinations", "Usage rules"], 1),
  
  generateBasicLessonContent(11, "Present Continuous Tense", "現在進行形", "Express actions happening now using be + -ing", ["Formation rules", "Time expressions", "Present simple vs continuous"], 2),
  
  generateBasicLessonContent(12, "Can and Can't", "助動詞can", "Express ability, possibility, and permission", ["Ability and skills", "Requests and permission", "Negative forms"], 2),
  
  generateBasicLessonContent(13, "Past Simple Tense", "過去形", "Talk about completed actions in the past", ["Regular verbs (-ed)", "Irregular verbs", "Time expressions"], 2),
  
  generateBasicLessonContent(14, "There is/There are", "存在を表す表現", "Describe what exists in a place", ["Singular vs plural", "Negative forms", "Question formation"], 2),
  
  generateBasicLessonContent(15, "Countable and Uncountable Nouns", "可算名詞と不可算名詞", "Understand the difference between countable and uncountable nouns", ["Some and any", "Much and many", "A lot of"], 2),
  
  generateBasicLessonContent(16, "Comparative Adjectives", "比較級", "Compare two things using adjectives", ["Short adjectives (-er)", "Long adjectives (more)", "Irregular comparatives"], 2),
  
  generateBasicLessonContent(17, "Superlative Adjectives", "最上級", "Express the highest degree of a quality", ["Short adjectives (-est)", "Long adjectives (most)", "Irregular superlatives"], 2),
  
  generateBasicLessonContent(18, "Future with 'will'", "未来形（will）", "Express future plans and predictions", ["Will vs won't", "Predictions", "Spontaneous decisions"], 2),
  
  generateBasicLessonContent(19, "Future with 'going to'", "未来形（going to）", "Talk about future plans and intentions", ["Plans and intentions", "Predictions with evidence", "Will vs going to"], 2),
  
  generateBasicLessonContent(20, "Past Continuous Tense", "過去進行形", "Describe ongoing actions in the past", ["Formation with was/were", "Interrupted actions", "Time expressions"], 2),
  
  generateBasicLessonContent(21, "Present Perfect Tense", "現在完了形", "Connect past actions to the present", ["Have/has + past participle", "Ever and never", "Already and yet"], 3),
  
  generateBasicLessonContent(22, "Modal Verbs: Should/Must", "助動詞（should/must）", "Express advice, obligation, and necessity", ["Should for advice", "Must for obligation", "Mustn't vs don't have to"], 3),
  
  generateBasicLessonContent(23, "Conditional Sentences (First)", "条件文（第一条件文）", "Express real possibilities in the future", ["If + present, will + base", "Unless", "When vs if"], 3),
  
  generateBasicLessonContent(24, "Passive Voice (Present)", "受動態（現在）", "Focus on the action rather than the doer", ["Be + past participle", "By + agent", "When to use passive"], 3),
  
  generateBasicLessonContent(25, "Reported Speech (Present)", "間接話法（現在）", "Report what someone says", ["Say vs tell", "Tense changes", "Reporting verbs"], 3),
  
  generateBasicLessonContent(26, "Relative Clauses", "関係詞節", "Connect sentences using who, which, that", ["Defining relative clauses", "Who, which, that", "Where and when"], 3),
  
  generateBasicLessonContent(27, "Past Perfect Tense", "過去完了形", "Express actions completed before another past action", ["Had + past participle", "Time expressions", "Past perfect vs past simple"], 3),
  
  generateBasicLessonContent(28, "Second Conditional", "仮定法過去", "Express hypothetical situations", ["If + past, would + base", "Unreal present situations", "Could and might"], 3),
  
  generateBasicLessonContent(29, "Passive Voice (Past)", "受動態（過去）", "Express past actions in passive form", ["Was/were + past participle", "Past passive vs present passive", "Complex passive structures"], 3),
  
  generateBasicLessonContent(30, "Advanced Grammar Review", "上級文法総復習", "Review and practice all major grammar points", ["Mixed tenses", "Complex sentences", "Common mistakes"], 3)
];

export const getLessonById = (id: number): Lesson | undefined => {
  return lessons.find(lesson => lesson.id === id);
};

export const getAvailableLessons = (currentLesson: number): Lesson[] => {
  return lessons.filter(lesson => lesson.id <= currentLesson);
};
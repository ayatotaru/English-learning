# English Learning Platform with Supabase Authentication

React + TypeScript + Supabaseを使用した英語学習プラットフォームです。

## 🔐 認証機能

### 実装済み機能
- ✅ メールアドレス・パスワード認証
- ✅ Google OAuth認証
- ✅ パスワードリセット
- ✅ Protected Routes（認証が必要なページの保護）
- ✅ ユーザープロファイル管理
- ✅ 学習進捗データの自動同期

### セキュリティ機能
- ✅ Row Level Security (RLS) による データアクセス制御
- ✅ ユーザーは自分のデータのみアクセス可能
- ✅ 認証状態の自動監視・更新
- ✅ セッション管理とトークン自動更新

## 🗄️ データベース設計

### テーブル構成

#### `profiles` テーブル
```sql
- id (uuid, primary key, references auth.users)
- email (text, unique)
- full_name (text, nullable)
- avatar_url (text, nullable)
- created_at (timestamptz)
- updated_at (timestamptz)
```

#### `user_progress` テーブル
```sql
- id (uuid, primary key)
- user_id (text, references auth.users.id)
- current_lesson (integer)
- total_lessons_completed (integer)
- total_points (integer)
- streak (integer)
- last_study_date (text)
- lesson_progress (jsonb)
- created_at (timestamptz)
- updated_at (timestamptz)
```

### RLSポリシー
- ユーザーは自分のプロファイルのみ閲覧・更新可能
- ユーザーは自分の学習進捗のみアクセス可能
- 認証されたユーザーのみデータアクセス許可

## 🚀 セットアップ手順

### 1. Supabaseプロジェクトの設定

1. [Supabase](https://supabase.com)でプロジェクトを作成
2. 環境変数を設定:
```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

### 2. データベースマイグレーション

Supabaseダッシュボードで以下のSQLを実行:
```sql
-- supabase/migrations/create_auth_tables.sql の内容を実行
```

### 3. Google OAuth設定（オプション）

1. [Google Cloud Console](https://console.cloud.google.com)でプロジェクトを作成
2. OAuth 2.0クライアントIDを作成
3. Supabaseダッシュボードの認証設定でGoogle Providerを有効化
4. クライアントIDとシークレットを設定

### 4. アプリケーションの起動

```bash
npm install
npm run dev
```

## 📱 使用方法

### 認証フロー

1. **サインアップ**: 新規ユーザー登録
   - メールアドレスとパスワードで登録
   - またはGoogleアカウントで登録

2. **サインイン**: 既存ユーザーのログイン
   - メールアドレスとパスワード
   - またはGoogleアカウント

3. **パスワードリセット**: パスワードを忘れた場合
   - メールアドレスでリセットリンクを送信

### データ管理

- **自動プロファイル作成**: 新規ユーザー登録時に自動でプロファイルと学習進捗データを作成
- **リアルタイム同期**: 学習進捗は自動的にSupabaseに保存
- **セキュアアクセス**: RLSにより他のユーザーのデータにはアクセス不可

## 🔧 技術スタック

- **Frontend**: React 18, TypeScript, Tailwind CSS
- **Backend**: Supabase (PostgreSQL, Auth, RLS)
- **State Management**: React Context API
- **Icons**: Lucide React
- **Build Tool**: Vite

## 🛡️ セキュリティベストプラクティス

1. **Row Level Security (RLS)**: すべてのテーブルでRLSを有効化
2. **型安全性**: TypeScriptによる型チェック
3. **エラーハンドリング**: 適切なエラーメッセージとフォールバック
4. **セッション管理**: 自動トークン更新とセッション永続化
5. **入力検証**: フォーム入力の検証とサニタイゼーション

## 📚 主要コンポーネント

### 認証関連
- `AuthProvider`: 認証状態の管理
- `AuthModal`: ログイン・サインアップモーダル
- `AuthButton`: 認証ボタンとユーザーメニュー
- `ProtectedRoute`: 認証が必要なルートの保護

### フック
- `useAuth`: 認証状態とメソッドへのアクセス
- `useUserProgress`: ユーザー学習進捗の管理

### 型定義
- `AuthUser`: 認証ユーザー情報
- `UserProfile`: ユーザープロファイル
- `AuthContextType`: 認証コンテキストの型

## 🔄 データフロー

1. ユーザーがログイン
2. `AuthProvider`が認証状態を管理
3. `useUserProgress`が学習進捗データを取得
4. コンポーネントが認証状態に基づいてレンダリング
5. 学習進捗の更新時に自動的にSupabaseに保存

## 🚨 エラーハンドリング

- ネットワークエラー
- 認証エラー
- データベースエラー
- バリデーションエラー

すべてのエラーは適切にキャッチされ、ユーザーフレンドリーなメッセージで表示されます。